import React from 'react';
import { TabType, ChipPreset } from '../types';
import { CHIP_PRESETS } from '../data/presets';
import { Cpu, Zap, Signal, LayoutGrid, Bot, Activity, Sparkles } from 'lucide-react';

interface HeaderProps {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  selectedPreset: ChipPreset;
  onSelectPreset: (preset: ChipPreset) => void;
  onRunAiAnalysis: () => void;
  isAiLoading: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  selectedPreset,
  onSelectPreset,
  onRunAiAnalysis,
  isAiLoading,
}) => {
  return (
    <header className="bg-slate-900 border-b border-slate-800 text-slate-100 sticky top-0 z-40 shadow-xl backdrop-blur-md bg-opacity-95">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between py-3 gap-3">
          {/* Logo & App Info */}
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-indigo-600 shadow-lg shadow-cyan-500/20 text-white">
              <Cpu className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-xl font-bold tracking-tight text-white font-mono">
                  GAAFET <span className="text-cyan-400">Silicon Studio</span>
                </h1>
                <span className="px-2 py-0.5 text-xs font-mono font-semibold rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800">
                  2nm GAAFET
                </span>
              </div>
              <p className="text-xs text-slate-400">
                次世代手機晶片核心：對角線佈局 · 布朗能窗 DVFS · AM-PM 相位位移修正
              </p>
            </div>
          </div>

          {/* Preset Selector & AI Button */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 lg:pb-0">
            <div className="flex items-center bg-slate-800/80 p-1 rounded-lg border border-slate-700/80 text-xs">
              <span className="text-slate-400 px-2 font-mono hidden sm:inline">預設架構:</span>
              <select
                value={selectedPreset.id}
                onChange={(e) => {
                  const p = CHIP_PRESETS.find((x) => x.id === e.target.value);
                  if (p) onSelectPreset(p);
                }}
                className="bg-slate-900 text-cyan-300 border border-slate-700 rounded px-2 py-1 font-mono focus:outline-none focus:ring-1 focus:ring-cyan-500 cursor-pointer"
              >
                {CHIP_PRESETS.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={onRunAiAnalysis}
              disabled={isAiLoading}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-medium text-xs shadow-md shadow-indigo-500/20 transition-all duration-200 cursor-pointer disabled:opacity-50 shrink-0"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-spin" style={{ animationDuration: '3s' }} />
              <span>{isAiLoading ? 'AI 驗證中...' : 'AI 物理驗證診斷'}</span>
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex space-x-1 overflow-x-auto border-t border-slate-800/80 pt-2 pb-1 text-xs sm:text-sm font-medium">
          <button
            onClick={() => setActiveTab('layout')}
            className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-all ${
              activeTab === 'layout'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <LayoutGrid className="w-4 h-4 text-cyan-400" />
            <span>結構佈局 (log_45-degree)</span>
          </button>

          <button
            onClick={() => setActiveTab('power')}
            className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-all ${
              activeTab === 'power'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Zap className="w-4 h-4 text-amber-400" />
            <span>功耗管理 (brownian_energy)</span>
          </button>

          <button
            onClick={() => setActiveTab('signal')}
            className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-all ${
              activeTab === 'signal'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Signal className="w-4 h-4 text-emerald-400" />
            <span>訊號完整性 (AM-PM.shift)</span>
          </button>

          <button
            onClick={() => setActiveTab('overview')}
            className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-all ${
              activeTab === 'overview'
                ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Activity className="w-4 h-4 text-indigo-400" />
            <span>全方位 PPA 總覽</span>
          </button>
        </div>
      </div>
    </header>
  );
};
