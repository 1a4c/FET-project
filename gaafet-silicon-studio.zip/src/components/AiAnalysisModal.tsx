import React from 'react';
import { X, Bot, Sparkles, Copy, Check, FileText } from 'lucide-react';

interface AiAnalysisModalProps {
  isOpen: boolean;
  onClose: () => void;
  report: string | null;
  isLoading: boolean;
}

export const AiAnalysisModal: React.FC<AiAnalysisModalProps> = ({
  isOpen,
  onClose,
  report,
  isLoading,
}) => {
  const [copied, setCopied] = React.useState(false);

  if (!isOpen) return null;

  const handleCopy = () => {
    if (report) {
      navigator.clipboard.writeText(report);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-3xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-950/80">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-600 text-white shadow-md">
              <Sparkles className="w-5 h-5 animate-spin" style={{ animationDuration: '4s' }} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100 font-mono">
                AI 晶片物理驗證診斷報告 (Physical Verification Report)
              </h3>
              <p className="text-xs text-slate-400">Gemini 3.6 Flash Silicon Architect AI</p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {report && (
              <button
                onClick={handleCopy}
                className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition cursor-pointer text-xs flex items-center space-x-1 font-mono"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                <span>{copied ? '已複製' : '複製報告'}</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-4 text-slate-200 text-sm font-sans leading-relaxed">
          {isLoading ? (
            <div className="py-16 flex flex-col items-center justify-center space-y-4">
              <div className="relative">
                <div className="w-12 h-12 rounded-full border-4 border-indigo-500/20 border-t-indigo-500 animate-spin" />
                <Bot className="w-6 h-6 text-indigo-400 absolute inset-0 m-auto" />
              </div>
              <div className="text-center space-y-1 font-mono">
                <p className="text-sm font-bold text-slate-200">正在進行 2nm GAAFET 晶片微架構與 PPA 分析...</p>
                <p className="text-xs text-slate-400">計算 45-degree 寄生電容、布朗熱能窗與 AM-PM 射頻相位容限</p>
              </div>
            </div>
          ) : report ? (
            <div className="prose prose-invert max-w-none text-xs sm:text-sm font-sans whitespace-pre-line leading-relaxed">
              {report}
            </div>
          ) : (
            <div className="text-center py-12 text-slate-400 font-mono text-xs">
              點擊「生成驗證報告」按鈕以分析目前晶片參數。
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-slate-800 bg-slate-950/80 text-right">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono font-semibold cursor-pointer"
          >
            關閉視窗
          </button>
        </div>
      </div>
    </div>
  );
};
