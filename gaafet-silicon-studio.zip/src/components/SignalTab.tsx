import React, { useRef, useEffect } from 'react';
import { SignalParams } from '../types';
import { Signal, Radio, ArrowUpRight, ShieldCheck, Zap, Activity, CheckCircle2, AlertCircle } from 'lucide-react';

interface SignalTabProps {
  params: SignalParams;
  onChange: (updated: SignalParams) => void;
}

export const SignalTab: React.FC<SignalTabProps> = ({ params, onChange }) => {
  const constellationCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const transferCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Physics & RF Calculations
  // AM-PM Phase Distortion: delta_phi = coeff * (Input Power Factor)^1.5
  const normalizedPower = Math.pow(10, (params.paInputPowerDbm - 10) / 10);
  const rawPhaseShiftDeg = params.nonLinearityCoeff * normalizedPower * 12.5;

  // Effective Phase Shift with / without Self-Correction
  const effectivePhaseShiftDeg = params.amPmCorrection
    ? rawPhaseShiftDeg * 0.08 // DPD / FET Bias Compensation removes 92% of phase error
    : rawPhaseShiftDeg;

  // EVM calculation (dB & %)
  // EVM increases dramatically with uncompensated phase shift
  const baseEvmDb = params.modulation === 'QAM-4096' ? -42 : -34;
  const evmDegradation = effectivePhaseShiftDeg * 2.8;
  const calculatedEvmDb = baseEvmDb + evmDegradation;
  const calculatedEvmPct = Math.min(25, Math.pow(10, calculatedEvmDb / 20) * 100);

  // Upload Throughput Impact (Max 5.8 Gbps for Wi-Fi 7 QAM-4096)
  const maxThroughputGbps = params.carrierFreqGHz > 20 ? 10.0 : 5.8;
  // Throughput drops if EVM exceeds threshold (-32dB for QAM-4096)
  const evmThresholdDb = -32;
  let throughputPenalty = 0;
  if (calculatedEvmDb > evmThresholdDb) {
    throughputPenalty = Math.min(0.85, (calculatedEvmDb - evmThresholdDb) * 0.08);
  }
  const uploadSpeedGbps = Math.max(0.2, maxThroughputGbps * (1 - throughputPenalty));

  // Render Constellation Diagram
  useEffect(() => {
    const canvas = constellationCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // Dark RF Spectrum Canvas
    ctx.fillStyle = '#020617';
    ctx.fillRect(0, 0, width, height);

    const centerX = width / 2;
    const centerY = height / 2;
    const radius = width * 0.38;

    // Grid Axes & Target Circles
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;

    ctx.beginPath();
    ctx.moveTo(centerX, 20);
    ctx.lineTo(centerX, height - 20);
    ctx.moveTo(20, centerY);
    ctx.lineTo(width - 20, centerY);
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(centerX, centerY, radius * 0.5, 0, Math.PI * 2);
    ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
    ctx.stroke();

    // Determine grid size based on modulation
    let gridSize = 4; // 16-QAM default
    if (params.modulation === 'QAM-64') gridSize = 8;
    if (params.modulation === 'QAM-256') gridSize = 16;
    if (params.modulation === 'QAM-1024' || params.modulation === 'QAM-4096') gridSize = 24;

    const step = (radius * 1.6) / (gridSize - 1);
    const startX = centerX - (radius * 0.8);
    const startY = centerY - (radius * 0.8);

    // Draw Constellation Points with AM-PM Phase Rotation Distortion
    const phaseRad = (effectivePhaseShiftDeg * Math.PI) / 180;

    for (let i = 0; i < gridSize; i++) {
      for (let j = 0; j < gridSize; j++) {
        const idealX = startX + i * step - centerX;
        const idealY = startY + j * step - centerY;

        // Radius from origin determines AM-PM phase shift amount (outer points shift more)
        const distFromCenter = Math.sqrt(idealX * idealX + idealY * idealY);
        const normDist = distFromCenter / (radius * 0.8);
        const pointPhaseShift = phaseRad * Math.pow(normDist, 1.6);

        // Apply polar rotation: x' = x cos(phi) - y sin(phi)
        const rotatedX = idealX * Math.cos(pointPhaseShift) - idealY * Math.sin(pointPhaseShift);
        const rotatedY = idealX * Math.sin(pointPhaseShift) + idealY * Math.cos(pointPhaseShift);

        const finalX = centerX + rotatedX;
        const finalY = centerY + rotatedY;

        // Draw Symbol Points with Scatter Blur based on EVM
        const scatterRadius = Math.max(1, calculatedEvmPct * 0.6);

        ctx.fillStyle = params.amPmCorrection ? '#10b981' : '#f43f5e';
        ctx.beginPath();
        ctx.arc(
          finalX + (Math.random() - 0.5) * scatterRadius,
          finalY + (Math.random() - 0.5) * scatterRadius,
          gridSize > 16 ? 1.5 : 2.5,
          0,
          Math.PI * 2
        );
        ctx.fill();
      }
    }

    // Overlay Status Text
    ctx.fillStyle = '#f8fafc';
    ctx.font = 'bold 12px monospace';
    ctx.fillText(`${params.modulation} (${params.carrierFreqGHz} GHz)`, 20, 25);

    ctx.fillStyle = params.amPmCorrection ? '#34d399' : '#f87171';
    ctx.font = '11px monospace';
    ctx.fillText(
      params.amPmCorrection
        ? 'AM-PM 自我修正: 已開啟 (相位差 < 0.5°)'
        : `AM-PM 相位位移: ${effectivePhaseShiftDeg.toFixed(1)}° (未修正嚴重旋轉)`,
      20,
      42
    );
  }, [params, effectivePhaseShiftDeg, calculatedEvmPct]);

  // Render Transfer Curve (AM-PM Phase vs Amplitude)
  useEffect(() => {
    const canvas = transferCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, width, height);

    // Axes
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(40, 20);
    ctx.lineTo(40, height - 30);
    ctx.lineTo(width - 20, height - 30);
    ctx.stroke();

    // Labels
    ctx.fillStyle = '#94a3b8';
    ctx.font = '10px monospace';
    ctx.fillText('PA 輸入功率 Vin (dBm)', width - 130, height - 10);
    ctx.fillText('相位差 Δϕ (°)', 10, 15);

    // Curve 1: Uncompensated AM-PM Shift
    ctx.beginPath();
    ctx.strokeStyle = '#f43f5e';
    ctx.lineWidth = 2;
    for (let x = 40; x < width - 20; x++) {
      const normX = (x - 40) / (width - 60);
      const phaseDeg = params.nonLinearityCoeff * Math.pow(normX, 1.8) * 18;
      const y = (height - 30) - (phaseDeg / 20) * (height - 50);
      if (x === 40) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();

    // Curve 2: Compensated AM-PM Shift (Flat line near 0)
    if (params.amPmCorrection) {
      ctx.beginPath();
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 2.5;
      for (let x = 40; x < width - 20; x++) {
        const normX = (x - 40) / (width - 60);
        const phaseDeg = (params.nonLinearityCoeff * Math.pow(normX, 1.8) * 18) * 0.08;
        const y = (height - 30) - (phaseDeg / 20) * (height - 50);
        if (x === 40) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
  }, [params]);

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg relative overflow-hidden">
        <div className="absolute -right-10 -bottom-10 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                射頻功率放大器 AM-PM.shift
              </span>
              <span className="text-xs text-slate-400 font-mono">Wi-Fi 7 (4096-QAM) / 5G Sub-6 & mmWave</span>
            </div>
            <h2 className="text-lg font-bold text-slate-100 font-mono">
              AM-PM 相位失真自我修正 (AM-to-PM Phase Distortion Self-Correction)
            </h2>
            <p className="text-xs text-slate-300 leading-relaxed max-w-3xl">
              在手機 Wi-Fi 7 (QAM-4096) 與 5G 高頻射頻前端 (RF Front-End) 中，FET 功率放大器 (PA) 在高振幅訊號下會產生非線性相位位移 (<code className="text-emerald-300 font-mono font-bold bg-slate-800 px-1 py-0.5 rounded">AM-PM.shift</code>)。若缺乏 FET 閘極偏壓自我修正或數位預失真 (DPD)，星狀圖符號將發生旋轉模糊，導致 EVM 惡化，上傳速度大幅下降。
            </p>
          </div>

          <div className="flex items-center space-x-3 bg-slate-950/80 p-3 rounded-xl border border-slate-800 shrink-0">
            <div className="text-right font-mono">
              <div className="text-xs text-slate-400">手機上傳速率 (Upload Throughput)</div>
              <div className="text-xl font-black text-emerald-400">
                {uploadSpeedGbps.toFixed(2)} Gbps
              </div>
            </div>
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
              <ArrowUpRight className="w-6 h-6" />
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Constellation & Transfer Curve */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Radio className="w-4 h-4 text-emerald-400" />
                <h3 className="text-sm font-bold text-slate-200 font-mono">
                  高頻射頻星狀圖分析 (Constellation Diagram & EVM)
                </h3>
              </div>
              <div className="flex items-center space-x-2 text-xs font-mono">
                <span className="text-slate-400">自我修正:</span>
                <button
                  onClick={() => onChange({ ...params, amPmCorrection: !params.amPmCorrection })}
                  className={`px-3 py-1 rounded font-bold cursor-pointer transition-all ${
                    params.amPmCorrection
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/50'
                      : 'bg-rose-500/20 text-rose-300 border border-rose-500/50'
                  }`}
                >
                  {params.amPmCorrection ? '✓ 已開啟 (ON)' : '✕ 已關閉 (OFF)'}
                </button>
              </div>
            </div>

            {/* Constellation Canvas */}
            <div className="relative rounded-xl overflow-hidden border border-slate-800 bg-slate-950">
              <canvas
                ref={constellationCanvasRef}
                width={600}
                height={300}
                className="w-full h-[300px] object-contain block"
              />
            </div>

            {/* Metrics Bar */}
            <div className="grid grid-cols-4 gap-2 pt-1 font-mono text-xs">
              <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                <div className="text-[10px] text-slate-400">EVM Error Vector</div>
                <div className={`text-sm font-bold ${calculatedEvmDb < -35 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {calculatedEvmDb.toFixed(1)} dB <span className="text-[10px]">({calculatedEvmPct.toFixed(2)}%)</span>
                </div>
              </div>

              <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                <div className="text-[10px] text-slate-400">相位位移 (Phase Shift)</div>
                <div className="text-sm font-bold text-amber-400">
                  Δϕ = {effectivePhaseShiftDeg.toFixed(2)}°
                </div>
              </div>

              <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                <div className="text-[10px] text-slate-400">上傳連線速度</div>
                <div className="text-sm font-bold text-sky-400">
                  {uploadSpeedGbps.toFixed(2)} Gbps
                </div>
              </div>

              <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                <div className="text-[10px] text-slate-400">信噪比 (SNR Margin)</div>
                <div className="text-sm font-bold text-indigo-400">
                  {(42 + calculatedEvmDb).toFixed(1)} dB
                </div>
              </div>
            </div>
          </div>

          {/* Transfer Curve Box */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-2">
            <h4 className="text-xs font-bold text-slate-300 font-mono flex items-center justify-between">
              <span className="flex items-center space-x-1.5">
                <Activity className="w-4 h-4 text-emerald-400" />
                <span>AM-PM 特性轉移曲線 (Amplitude vs Phase Shift)</span>
              </span>
              <span className="text-[10px] text-slate-400">紅色: 未修正 | 綠色: 自我修正後</span>
            </h4>
            <div className="rounded-xl overflow-hidden border border-slate-800 bg-slate-950">
              <canvas
                ref={transferCanvasRef}
                width={560}
                height={120}
                className="w-full h-[120px] object-contain block"
              />
            </div>
          </div>
        </div>

        {/* Right: Controls & Parameters */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-5">
            <div className="border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-slate-100 font-mono flex items-center space-x-2">
                <Signal className="w-4 h-4 text-emerald-400" />
                <span>RF & AM-PM Distortion Parameters</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">高頻微波與射頻功率放大器 (PA) 參數調整</p>
            </div>

            {/* Modulation Selector */}
            <div className="space-y-2 font-mono text-xs">
              <label className="text-slate-300 font-semibold">調變技術 (Modulation Scheme)</label>
              <div className="grid grid-cols-2 gap-2">
                {['QAM-64', 'QAM-256', 'QAM-1024', 'QAM-4096'].map((mod) => (
                  <button
                    key={mod}
                    onClick={() => onChange({ ...params, modulation: mod as any })}
                    className={`p-2 rounded-lg border text-center transition-all cursor-pointer ${
                      params.modulation === mod
                        ? 'bg-emerald-500/20 border-emerald-500/60 text-emerald-200 font-bold'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {mod} {mod === 'QAM-4096' ? '(Wi-Fi 7)' : ''}
                  </button>
                ))}
              </div>
            </div>

            {/* Carrier Frequency */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-xs font-mono">
                <span className="text-slate-300">載波頻率 (Carrier Frequency)</span>
                <span className="text-emerald-400 font-bold font-mono">{params.carrierFreqGHz} GHz</span>
              </div>
              <div className="flex gap-2 text-xs font-mono">
                <button
                  onClick={() => onChange({ ...params, carrierFreqGHz: 5.8 })}
                  className={`flex-1 p-2 rounded-lg border cursor-pointer ${
                    params.carrierFreqGHz === 5.8
                      ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300 font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  5.8 GHz (Wi-Fi 7)
                </button>
                <button
                  onClick={() => onChange({ ...params, carrierFreqGHz: 28.0 })}
                  className={`flex-1 p-2 rounded-lg border cursor-pointer ${
                    params.carrierFreqGHz === 28.0
                      ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300 font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  28.0 GHz (5G mmWave)
                </button>
              </div>
            </div>

            {/* PA Input Power */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-xs font-mono">
                <span className="text-slate-300">PA 輸入功率 (Input Power Vin)</span>
                <span className="text-slate-100">{params.paInputPowerDbm} dBm</span>
              </div>
              <input
                type="range"
                min={-5}
                max={15}
                step={1}
                value={params.paInputPowerDbm}
                onChange={(e) => onChange({ ...params, paInputPowerDbm: Number(e.target.value) })}
                className="w-full accent-emerald-400 bg-slate-800 h-2 rounded-lg cursor-pointer"
              />
            </div>

            {/* PA Non-linearity Coefficient */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-xs font-mono">
                <span className="text-slate-300">FET 非線性失真增益 (Non-linearity Gain)</span>
                <span className="text-slate-100">{params.nonLinearityCoeff.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min={0.1}
                max={1.0}
                step={0.05}
                value={params.nonLinearityCoeff}
                onChange={(e) => onChange({ ...params, nonLinearityCoeff: Number(e.target.value) })}
                className="w-full accent-emerald-400 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
              />
            </div>

            {/* Summary Highlights */}
            <div className="bg-slate-950/80 p-3.5 rounded-xl border border-slate-800 space-y-2 text-xs">
              <div className="font-bold text-slate-200 font-mono flex items-center space-x-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>AM-PM.shift 修正效益</span>
              </div>
              <ul className="text-slate-400 space-y-1 text-[11px] list-disc list-inside">
                <li>將高頻 4096-QAM 訊號相位偏轉控制於 0.5° 以內。</li>
                <li>EVM 提高至 -40 dB 以上，解鎖 5.8 Gbps 極限上傳頻寬。</li>
                <li>避免高頻多天線 Beamforming 發生相位失真。</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
