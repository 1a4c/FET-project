import React from 'react';
import { LayoutParams, PowerParams, SignalParams, ChipPreset } from '../types';
import { Cpu, Zap, Signal, LayoutGrid, CheckCircle2, Sparkles, Activity, ShieldAlert, Award } from 'lucide-react';

interface OverviewTabProps {
  layout: LayoutParams;
  power: PowerParams;
  signal: SignalParams;
  preset: ChipPreset;
  onRunAiAnalysis: () => void;
  isAiLoading: boolean;
}

export const OverviewTab: React.FC<OverviewTabProps> = ({
  layout,
  power,
  signal,
  preset,
  onRunAiAnalysis,
  isAiLoading,
}) => {
  // Score calculations
  const layoutScore = Math.min(100, Math.max(60, 65 + (layout.routingAngle / 45) * 35));
  const powerScore = Math.min(100, Math.max(60, power.mode === 'brownian' ? 95 : 68));
  const signalScore = Math.min(100, Math.max(60, signal.amPmCorrection ? 98 : 62));
  const overallScore = Number(((layoutScore * 0.35) + (powerScore * 0.35) + (signalScore * 0.30)).toFixed(1));

  return (
    <div className="space-y-6">
      {/* Top Overall Score Card */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-indigo-900/80 text-indigo-300 border border-indigo-700">
                PPA 綜合評價 (Power, Performance, Area)
              </span>
              <span className="text-xs text-slate-400 font-mono">2nm GAAFET Silicon Benchmark</span>
            </div>
            <h2 className="text-2xl font-black text-white font-mono">
              {preset.name}
            </h2>
            <p className="text-xs text-slate-300 max-w-2xl">
              結合 <span className="text-cyan-400 font-mono font-bold">log_45-degree</span> 45°金屬佈局、<span className="text-amber-400 font-mono font-bold">brownian_energy</span> 預判式 DVFS，以及 <span className="text-emerald-400 font-mono font-bold">AM-PM.shift</span> 射頻相位自我修正。
            </p>
          </div>

          <div className="flex items-center space-x-4 bg-slate-950/80 p-4 rounded-2xl border border-slate-800/80 shrink-0">
            <div className="text-center font-mono">
              <div className="text-[11px] text-slate-400">總體架構得分</div>
              <div className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-amber-300 to-emerald-400">
                {overallScore}
              </div>
              <div className="text-[10px] text-slate-500">GRADE A+ SILICON</div>
            </div>

            <div className="p-3 rounded-xl bg-indigo-500/10 text-indigo-400">
              <Award className="w-8 h-8" />
            </div>
          </div>
        </div>
      </div>

      {/* 3 Pillar Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Pillar 1: Layout */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center space-x-2">
              <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400">
                <LayoutGrid className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-100 font-mono">1. 結構佈局</h3>
                <div className="text-[11px] text-cyan-400 font-mono">log_45-degree</div>
              </div>
            </div>
            <div className="text-right font-mono">
              <div className="text-lg font-bold text-cyan-400">{layoutScore}</div>
              <div className="text-[10px] text-slate-500">/ 100</div>
            </div>
          </div>

          <div className="space-y-2 text-xs font-mono text-slate-300">
            <div className="flex justify-between">
              <span className="text-slate-400">佈局模式:</span>
              <span className="font-bold text-cyan-300">
                {layout.routingAngle === 45 ? '45° log_45-degree 對角' : `${layout.routingAngle}° 正交/斜角`}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">寄生電容降低:</span>
              <span className="text-emerald-400 font-bold">
                {layout.routingAngle === 45 ? '-29.3%' : '0%'}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">RC 訊號延遲:</span>
              <span className="text-amber-400">{(0.85 * layout.wireLengthMicrons * 0.12 * 1e-3).toFixed(2)} ps</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">切換功耗節省:</span>
              <span className="text-cyan-400 font-bold">
                {(layout.routingAngle === 45 ? 18.5 : 0).toFixed(1)} mW
              </span>
            </div>
          </div>
        </div>

        {/* Pillar 2: Power */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center space-x-2">
              <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400">
                <Zap className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-100 font-mono">2. 功耗管理</h3>
                <div className="text-[11px] text-amber-400 font-mono">brownian_energy</div>
              </div>
            </div>
            <div className="text-right font-mono">
              <div className="text-lg font-bold text-amber-400">{powerScore}</div>
              <div className="text-[10px] text-slate-500">/ 100</div>
            </div>
          </div>

          <div className="space-y-2 text-xs font-mono text-slate-300">
            <div className="flex justify-between">
              <span className="text-slate-400">DVFS 演算法:</span>
              <span className="font-bold text-amber-300">
                {power.mode === 'brownian' ? '預判式布朗能窗' : '傳統反應型降頻'}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">能窗採樣視窗:</span>
              <span>{power.timeWindowMs} ms</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">熱失控降頻避開:</span>
              <span className="text-emerald-400 font-bold">
                {power.mode === 'brownian' ? '完全消除 (0 次卡頓)' : '頻繁發生 (75°C 硬降)'}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">影格率 FPS 穩定度:</span>
              <span className="text-amber-400 font-bold">
                {power.mode === 'brownian' ? '98.5%' : '72.0%'}
              </span>
            </div>
          </div>
        </div>

        {/* Pillar 3: Signal */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center space-x-2">
              <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
                <Signal className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-100 font-mono">3. 訊號完整性</h3>
                <div className="text-[11px] text-emerald-400 font-mono">AM-PM.shift</div>
              </div>
            </div>
            <div className="text-right font-mono">
              <div className="text-lg font-bold text-emerald-400">{signalScore}</div>
              <div className="text-[10px] text-slate-500">/ 100</div>
            </div>
          </div>

          <div className="space-y-2 text-xs font-mono text-slate-300">
            <div className="flex justify-between">
              <span className="text-slate-400">AM-PM 相位修正:</span>
              <span className={`font-bold ${signal.amPmCorrection ? 'text-emerald-300' : 'text-rose-400'}`}>
                {signal.amPmCorrection ? '✓ 已啟動 FET 自我補償' : '✕ 未修正 (嚴重偏轉)'}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">高頻調變:</span>
              <span>{signal.modulation} ({signal.carrierFreqGHz} GHz)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">EVM 向量誤差:</span>
              <span className="text-emerald-400 font-bold">
                {signal.amPmCorrection ? '-40.5 dB (1.18%)' : '-22.4 dB (7.58%)'}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">手機極限上傳速度:</span>
              <span className="text-sky-400 font-bold">
                {signal.amPmCorrection ? '5.8 Gbps (Wi-Fi 7)' : '1.2 Gbps'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Action Banner for AI Diagnostics */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="space-y-1 text-center md:text-left">
          <h3 className="text-base font-bold text-slate-100 font-mono flex items-center justify-center md:justify-start space-x-2">
            <Sparkles className="w-5 h-5 text-indigo-400 animate-pulse" />
            <span>啟動 AI 晶片物理驗證診斷 (Gemini AI Physical Verification)</span>
          </h3>
          <p className="text-xs text-slate-400">
            針對目前的 45-degree 佈局、布朗熱能窗 DVFS 與射頻 AM-PM 參數生成 EDA 層級診斷報告。
          </p>
        </div>

        <button
          onClick={onRunAiAnalysis}
          disabled={isAiLoading}
          className="px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-600 via-indigo-600 to-purple-600 hover:from-cyan-500 hover:to-purple-500 text-white font-bold font-mono text-sm shadow-xl shadow-indigo-500/25 transition-all duration-200 cursor-pointer disabled:opacity-50 shrink-0"
        >
          {isAiLoading ? 'AI 診斷運算中...' : '生成完整物理驗證報告'}
        </button>
      </div>
    </div>
  );
};
