import React, { useRef, useEffect } from 'react';
import { LayoutParams } from '../types';
import { LayoutGrid, ArrowRight, Zap, ShieldAlert, Cpu, Info, CheckCircle2 } from 'lucide-react';

interface LayoutTabProps {
  params: LayoutParams;
  onChange: (updated: LayoutParams) => void;
}

export const LayoutTab: React.FC<LayoutTabProps> = ({ params, onChange }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Physics Calculations
  const isDiagonal = params.routingAngle > 20;
  // Parasitic Capacitance model
  // Orthogonal d_eff = metalSpacing
  // Diagonal d_eff = metalSpacing * (1 + sin(angle * PI / 180) * 0.414)
  const angleRad = (params.routingAngle * Math.PI) / 180;
  const distMultiplier = 1 + Math.sin(angleRad) * 0.414;
  const effectiveDistance = params.metalSpacing * distMultiplier;

  // C = (kappa * epsilon_0 * Area) / d
  // Normalized base capacitance per micron (fF/um)
  const eps0 = 8.854e-3; // fF/nm
  const baseAreaPerMicron = 1000 * 20; // nm^2
  const cCoupling = (params.dielectricConstant * eps0 * baseAreaPerMicron) / effectiveDistance / 100; // fF/um
  const cFringe = (params.dielectricConstant * 0.015); // fF/um
  const totalCapPerMicron = cCoupling + cFringe; // fF/um

  const totalCap = totalCapPerMicron * (params.wireLengthMicrons / 100); // fF
  
  // Wire Resistance (2nm metal 1 rho ~ 30 uOhm-cm)
  const wireResistance = 0.85 * params.wireLengthMicrons; // Ohms
  const rcDelayPs = wireResistance * totalCap * 1e-3; // ps

  // Dynamic Power: P = C * V^2 * f
  const dynamicPowerMw = (totalCap * 1e-15 * Math.pow(params.operatingVoltage, 2) * (params.operatingFreqGHz * 1e9) * 1e3);

  // Baseline 0-degree cap for comparison
  const baseCap0Deg = ((params.dielectricConstant * eps0 * baseAreaPerMicron) / params.metalSpacing / 100) + cFringe;
  const baseCapTotal = baseCap0Deg * (params.wireLengthMicrons / 100);
  const capReductionPct = Math.max(0, ((baseCapTotal - totalCap) / baseCapTotal) * 100);
  const powerSavingsMw = Math.max(0, (baseCapTotal - totalCap) * 1e-15 * Math.pow(params.operatingVoltage, 2) * (params.operatingFreqGHz * 1e9) * 1e3);

  // Draw Layout Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // Background
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, width, height);

    // Draw Grid / Substrate
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;
    const gridSize = 20;
    for (let x = 0; x < width; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
    for (let y = 0; y < height; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    // Draw Nanosheet GAAFET Gate Pillars (Vertical Columns)
    const gatePitchPx = Math.max(16, params.gatePitch * 1.5);
    for (let x = 40; x < width - 40; x += gatePitchPx) {
      // GAAFET Gate Electrode (Cyan/Indigo Glow)
      ctx.fillStyle = 'rgba(6, 182, 212, 0.15)';
      ctx.fillRect(x - 6, 30, 12, height - 60);

      ctx.strokeStyle = '#0891b2';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(x - 6, 30, 12, height - 60);

      // Draw Nanosheets inside Gate (Horizontal stacked ribbons)
      const numSheets = params.nanosheetLayers;
      const sheetSpacing = (height - 100) / (numSheets + 1);
      for (let s = 1; s <= numSheets; s++) {
        const sy = 40 + s * sheetSpacing;
        ctx.fillStyle = '#38bdf8';
        ctx.fillRect(x - 10, sy - 2, 20, 4);
      }
    }

    // Draw Metal Routing Overlay (0-degree vs 45-degree log_45-degree)
    ctx.save();
    ctx.translate(width / 2, height / 2);

    const wireSpacingPx = params.metalSpacing * 1.2;
    const wireCount = 7;

    if (params.routingAngle === 0) {
      // Traditional 90-degree orthogonal routing (Red / Orange crosstalk risk)
      ctx.strokeStyle = '#f43f5e';
      ctx.lineWidth = 3;
      ctx.shadowColor = 'rgba(244, 63, 94, 0.5)';
      ctx.shadowBlur = 6;

      for (let i = -Math.floor(wireCount / 2); i <= Math.floor(wireCount / 2); i++) {
        const y = i * wireSpacingPx;
        ctx.beginPath();
        ctx.moveTo(-width / 2 + 30, y);
        ctx.lineTo(width / 2 - 30, y);
        ctx.stroke();

        // Draw parallel electric field parasitic capacitance coupling lines
        if (i < Math.floor(wireCount / 2)) {
          ctx.strokeStyle = 'rgba(239, 68, 68, 0.3)';
          ctx.lineWidth = 1;
          ctx.setLineDash([3, 3]);
          for (let cx = -width / 2 + 50; cx < width / 2 - 50; cx += 35) {
            ctx.beginPath();
            ctx.moveTo(cx, y + 4);
            ctx.lineTo(cx, y + wireSpacingPx - 4);
            ctx.stroke();
          }
          ctx.setLineDash([]);
          ctx.strokeStyle = '#f43f5e';
          ctx.lineWidth = 3;
        }
      }
    } else {
      // log_45-degree Diagonal Routing (Emerald / Cyan high efficiency)
      const currentAngleRad = (params.routingAngle * Math.PI) / 180;
      
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 3;
      ctx.shadowColor = 'rgba(16, 185, 129, 0.6)';
      ctx.shadowBlur = 8;

      for (let i = -Math.floor(wireCount / 2); i <= Math.floor(wireCount / 2); i++) {
        const offset = i * (wireSpacingPx * distMultiplier);
        ctx.beginPath();
        
        // Rotate diagonal path
        const x1 = -width / 2 + 20;
        const y1 = offset - Math.tan(currentAngleRad) * (width / 3);
        const x2 = width / 2 - 20;
        const y2 = offset + Math.tan(currentAngleRad) * (width / 3);

        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();

        // Parasitic coupling is drastically reduced due to diagonal spacing
        if (i < Math.floor(wireCount / 2)) {
          ctx.strokeStyle = 'rgba(16, 185, 129, 0.2)';
          ctx.lineWidth = 1;
          ctx.setLineDash([4, 4]);
          ctx.beginPath();
          ctx.moveTo(0, offset + 2);
          ctx.lineTo(15, offset + wireSpacingPx * distMultiplier - 2);
          ctx.stroke();
          ctx.setLineDash([]);
          ctx.strokeStyle = '#10b981';
          ctx.lineWidth = 3;
        }
      }
    }

    ctx.restore();

    // Canvas Label Overlay
    ctx.fillStyle = '#f8fafc';
    ctx.font = 'bold 12px monospace';
    ctx.fillText(
      params.routingAngle === 45
        ? '佈局: log_45-degree (45° Diagonal Routing - Low Parasitic Capacitance)'
        : `佈局: ${params.routingAngle}° Standard Routing`,
      15,
      25
    );

    ctx.fillStyle = params.routingAngle === 45 ? '#34d399' : '#f87171';
    ctx.font = '11px monospace';
    ctx.fillText(
      `間距 (d_eff): ${effectiveDistance.toFixed(1)} nm | 寄生電容 C_para: ${totalCapPerMicron.toFixed(3)} fF/μm`,
      15,
      42
    );
  }, [params, effectiveDistance, totalCapPerMicron, distMultiplier]);

  return (
    <div className="space-y-6">
      {/* Top Banner Explanation */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg relative overflow-hidden">
        <div className="absolute -right-10 -bottom-10 w-48 h-48 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-cyan-900/80 text-cyan-300 border border-cyan-700">
                對角線佈局技術 log_45-degree
              </span>
              <span className="text-xs text-slate-400 font-mono">2nm GAAFET Standard Cell</span>
            </div>
            <h2 className="text-lg font-bold text-slate-100 font-mono">
              降低金屬導線寄生電容 (Parasitic Capacitance Reduction)
            </h2>
            <p className="text-xs text-slate-300 leading-relaxed max-w-3xl">
              在先進手機晶片 (如 2nm GAAFET) 中，導線間距已縮小至極限，傳統 90° 正交金屬層佈局會產生高額的平行耦合電容 (C_parasitic)。採用 <code className="text-cyan-300 font-mono font-bold bg-slate-800 px-1 py-0.5 rounded">log_45-degree</code> 對角線 routing 可將導線間距擴大 1.414 倍 (√2)，顯著降低導線串擾 (Crosstalk) 與動態功耗。
            </p>
          </div>

          <div className="flex items-center space-x-3 bg-slate-950/80 p-3 rounded-xl border border-slate-800 shrink-0">
            <div className="text-right font-mono">
              <div className="text-xs text-slate-400">寄生電容降低幅度</div>
              <div className="text-xl font-black text-cyan-400">
                -{capReductionPct.toFixed(1)}%
              </div>
            </div>
            <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400">
              <Zap className="w-6 h-6" />
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid: Visual Canvas + Parameter Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Interactive Standard Cell Floorplan Canvas */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-2">
                <LayoutGrid className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm font-bold text-slate-200 font-mono">
                  2nm GAAFET Nanosheet & Metal Routing Floorplan
                </h3>
              </div>
              <div className="flex items-center space-x-2 text-xs font-mono">
                <button
                  onClick={() => onChange({ ...params, routingAngle: 0 })}
                  className={`px-2.5 py-1 rounded transition-all cursor-pointer ${
                    params.routingAngle === 0
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 font-bold'
                      : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  傳統 90° 正交
                </button>
                <button
                  onClick={() => onChange({ ...params, routingAngle: 45 })}
                  className={`px-2.5 py-1 rounded transition-all cursor-pointer ${
                    params.routingAngle === 45
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold'
                      : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  log_45-degree 對角
                </button>
              </div>
            </div>

            <div className="relative rounded-xl overflow-hidden border border-slate-800 bg-slate-950">
              <canvas
                ref={canvasRef}
                width={600}
                height={320}
                className="w-full h-[320px] object-contain block"
              />
            </div>

            {/* Formula Reference Box */}
            <div className="mt-4 p-3 bg-slate-950/90 rounded-xl border border-slate-800 font-mono text-xs text-slate-300 space-y-1.5">
              <div className="flex items-center justify-between text-cyan-400 font-bold">
                <span>物理計算模型 (RC Delay & Capacitance Model):</span>
                <span>C_parasitic = (κ · ε0 · A) / d_eff</span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-400">
                <div>• 有效距離 d_eff: <span className="text-slate-200">{effectiveDistance.toFixed(2)} nm</span></div>
                <div>• 總寄生電容: <span className="text-cyan-300">{totalCap.toFixed(2)} fF</span></div>
                <div>• RC 傳輸延遲 (τ): <span className="text-amber-300">{rcDelayPs.toFixed(2)} ps</span></div>
                <div>• 動態功耗 P_dynamic: <span className="text-emerald-300">{dynamicPowerMw.toFixed(2)} mW</span></div>
              </div>
            </div>
          </div>

          {/* Quick Metrics Comparison Cards */}
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl space-y-1">
              <div className="text-[11px] text-slate-400 font-mono">寄生電容 (Capacitance)</div>
              <div className="text-lg font-mono font-bold text-cyan-400">
                {totalCapPerMicron.toFixed(3)} <span className="text-xs text-slate-400">fF/μm</span>
              </div>
              <div className="text-[10px] text-slate-500 font-mono">
                {params.routingAngle === 45 ? '已省去 1.414x 對角距離' : '正交平行串擾累積'}
              </div>
            </div>

            <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl space-y-1">
              <div className="text-[11px] text-slate-400 font-mono">RC 訊號延遲 (RC Delay)</div>
              <div className="text-lg font-mono font-bold text-amber-400">
                {rcDelayPs.toFixed(2)} <span className="text-xs text-slate-400">ps</span>
              </div>
              <div className="text-[10px] text-slate-500 font-mono">
                τ = R_metal × C_parasitic
              </div>
            </div>

            <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl space-y-1">
              <div className="text-[11px] text-slate-400 font-mono">節省切換功耗 (Power Saved)</div>
              <div className="text-lg font-mono font-bold text-emerald-400">
                {powerSavingsMw.toFixed(2)} <span className="text-xs text-slate-400">mW</span>
              </div>
              <div className="text-[10px] text-slate-500 font-mono">
                相當於增加 {(powerSavingsMw * 0.4).toFixed(1)} 分鐘續航
              </div>
            </div>
          </div>
        </div>

        {/* Right: Parameter Sliders & Controls */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-5">
            <div className="border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-slate-100 font-mono flex items-center space-x-2">
                <Cpu className="w-4 h-4 text-cyan-400" />
                <span>Layout & Physical Cell Parameters</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">微調 2nm GAAFET 核心金屬層與 Standard Cell 參數</p>
            </div>

            {/* Angle Slider */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-xs font-mono">
                <span className="text-slate-300 font-semibold">對角佈局角度 (Routing Angle)</span>
                <span className="text-cyan-400 font-bold bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                  {params.routingAngle}° {params.routingAngle === 45 ? '(log_45-degree)' : ''}
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={45}
                step={5}
                value={params.routingAngle}
                onChange={(e) => onChange({ ...params, routingAngle: Number(e.target.value) })}
                className="w-full accent-cyan-400 bg-slate-800 h-2 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>0° (傳統正交 Orthogonal)</span>
                <span>45° (log_45-degree 對角)</span>
              </div>
            </div>

            {/* Gate Pitch */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-xs font-mono">
                <span className="text-slate-300">閘極間距 (Gate Pitch)</span>
                <span className="text-slate-100">{params.gatePitch} nm</span>
              </div>
              <input
                type="range"
                min={16}
                max={32}
                step={1}
                value={params.gatePitch}
                onChange={(e) => onChange({ ...params, gatePitch: Number(e.target.value) })}
                className="w-full accent-cyan-400 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
              />
            </div>

            {/* Metal Spacing */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-xs font-mono">
                <span className="text-slate-300">金屬導線間距 (Metal Spacing)</span>
                <span className="text-slate-100">{params.metalSpacing} nm</span>
              </div>
              <input
                type="range"
                min={10}
                max={30}
                step={1}
                value={params.metalSpacing}
                onChange={(e) => onChange({ ...params, metalSpacing: Number(e.target.value) })}
                className="w-full accent-cyan-400 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
              />
            </div>

            {/* Low-k Dielectric Constant */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-xs font-mono">
                <span className="text-slate-300">介電常數 Low-κ Dielectric</span>
                <span className="text-slate-100 font-mono">κ = {params.dielectricConstant.toFixed(1)}</span>
              </div>
              <input
                type="range"
                min={1.8}
                max={3.9}
                step={0.1}
                value={params.dielectricConstant}
                onChange={(e) => onChange({ ...params, dielectricConstant: Number(e.target.value) })}
                className="w-full accent-cyan-400 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
              />
            </div>

            {/* Wire Length */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-xs font-mono">
                <span className="text-slate-300">臨界金屬走線長度 (Wire Length)</span>
                <span className="text-slate-100">{params.wireLengthMicrons} μm</span>
              </div>
              <input
                type="range"
                min={50}
                max={800}
                step={25}
                value={params.wireLengthMicrons}
                onChange={(e) => onChange({ ...params, wireLengthMicrons: Number(e.target.value) })}
                className="w-full accent-cyan-400 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
              />
            </div>

            {/* Voltage & Frequency */}
            <div className="grid grid-cols-2 gap-3 pt-2">
              <div className="space-y-1">
                <label className="text-[11px] text-slate-400 font-mono">工作電壓 Vdd (V)</label>
                <input
                  type="number"
                  step="0.02"
                  min="0.5"
                  max="1.1"
                  value={params.operatingVoltage}
                  onChange={(e) => onChange({ ...params, operatingVoltage: Number(e.target.value) })}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1 text-xs text-slate-100 font-mono focus:border-cyan-500 focus:outline-none"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[11px] text-slate-400 font-mono">主頻 Frequency (GHz)</label>
                <input
                  type="number"
                  step="0.1"
                  min="1.0"
                  max="5.0"
                  value={params.operatingFreqGHz}
                  onChange={(e) => onChange({ ...params, operatingFreqGHz: Number(e.target.value) })}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1 text-xs text-slate-100 font-mono focus:border-cyan-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Feature Highlights */}
            <div className="bg-slate-950/80 p-3.5 rounded-xl border border-slate-800 space-y-2 text-xs">
              <div className="font-bold text-slate-200 font-mono flex items-center space-x-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>log_45-degree 佈局優勢</span>
              </div>
              <ul className="text-slate-400 space-y-1 text-[11px] list-disc list-inside">
                <li>導線間距拉長至 1.414d，降低近鄰效應與金屬電容。</li>
                <li>時脈樹 (Clock Tree) 偏斜 t_skew 減少 ~18.5%。</li>
                <li>避免 2nm 高密度 Core 常見的走線壅塞 (Congestion)。</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
