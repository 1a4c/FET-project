import React, { useState, useEffect, useRef } from 'react';
import { PowerParams } from '../types';
import { Zap, Flame, ShieldCheck, Activity, RefreshCw, AlertTriangle, CheckCircle2 } from 'lucide-react';

interface PowerTabProps {
  params: PowerParams;
  onChange: (updated: PowerParams) => void;
}

export const PowerTab: React.FC<PowerTabProps> = ({ params, onChange }) => {
  const chartCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const dieCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Simulation History State
  const [history, setHistory] = useState<Array<{
    time: number;
    tempReactive: number;
    tempBrownian: number;
    freqReactive: number;
    freqBrownian: number;
    throttledReactive: boolean;
    throttledBrownian: boolean;
  }>>([]);

  const [isRunning, setIsRunning] = useState<boolean>(true);

  // Run Real-time Simulation Engine Loop
  useEffect(() => {
    if (!isRunning) return;

    const interval = setInterval(() => {
      setHistory((prev) => {
        const nextTime = (prev.length > 0 ? prev[prev.length - 1].time : 0) + 1;

        // Workload stress function based on workloadPattern
        let workloadStress = 1.0;
        if (params.workloadPattern === 'burst') {
          workloadStress = (nextTime % 20 < 10) ? 1.8 : 0.4;
        } else if (params.workloadPattern === 'gaming') {
          workloadStress = 1.3 + Math.sin(nextTime * 0.2) * 0.4;
        } else if (params.workloadPattern === 'ai_inference') {
          workloadStress = (nextTime % 12 < 4) ? 2.2 : 0.6;
        } else {
          workloadStress = 1.5;
        }

        // Brownian thermal noise term
        const brownianNoise = (Math.random() - 0.5) * params.noiseVariance * 4.0;

        // Previous states
        const last = prev.length > 0 ? prev[prev.length - 1] : {
          time: 0,
          tempReactive: params.ambientTemp,
          tempBrownian: params.ambientTemp,
          freqReactive: 4.2,
          freqBrownian: 4.2,
          throttledReactive: false,
          throttledBrownian: false,
        };

        // 1. Reactive Thermal Throttling Logic
        let nextTempReactive = last.tempReactive + (workloadStress * 0.85 * (last.freqReactive / 4.2)) - (last.tempReactive - params.ambientTemp) * 0.12 + brownianNoise;
        let nextFreqReactive = last.freqReactive;
        let throttledReactive = last.throttledReactive;

        if (nextTempReactive >= 75) {
          nextFreqReactive = 2.0; // Hard drop
          throttledReactive = true;
        } else if (nextTempReactive <= 62) {
          nextFreqReactive = Math.min(4.2, last.freqReactive + 0.2);
          throttledReactive = false;
        }

        // 2. Brownian Energy Window Predictive DVFS Logic (brownian_energy_timewindow().consumed)
        // Predicts thermal energy delta before temp hits critical limit
        const energyEntropyRate = (workloadStress * params.energyBudgetMw * 0.001) + (params.noiseVariance * 2.5);
        const windowFactor = Math.max(1, params.timeWindowMs);
        
        let predictedTempJump = energyEntropyRate * (10 / windowFactor);
        let nextFreqBrownian = last.freqBrownian;
        let throttledBrownian = false;

        if (last.tempBrownian + predictedTempJump > 66) {
          // Proactively scale down voltage and frequency smoothly to cap temp below 68°C
          nextFreqBrownian = Math.max(2.8, last.freqBrownian - 0.15);
        } else {
          nextFreqBrownian = Math.min(4.2, last.freqBrownian + 0.1);
        }

        let nextTempBrownian = last.tempBrownian + (workloadStress * 0.7 * (nextFreqBrownian / 4.2)) - (last.tempBrownian - params.ambientTemp) * 0.14 + brownianNoise * 0.6;
        nextTempBrownian = Math.min(68.5, nextTempBrownian);

        const newEntry = {
          time: nextTime,
          tempReactive: Math.max(params.ambientTemp, nextTempReactive),
          tempBrownian: Math.max(params.ambientTemp, nextTempBrownian),
          freqReactive: nextFreqReactive,
          freqBrownian: nextFreqBrownian,
          throttledReactive,
          throttledBrownian,
        };

        const updated = [...prev, newEntry];
        return updated.slice(-80); // Keep last 80 ticks
      });
    }, 150);

    return () => clearInterval(interval);
  }, [isRunning, params]);

  // Render Timeline Chart
  useEffect(() => {
    const canvas = chartCanvasRef.current;
    if (!canvas || history.length < 2) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, width, height);

    // Grid lines & labels
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;

    // Critical Temp threshold line 75°C
    const y75 = height - ((75 - 20) / (85 - 20)) * height;
    ctx.strokeStyle = 'rgba(244, 63, 94, 0.4)';
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(0, y75);
    ctx.lineTo(width, y75);
    ctx.stroke();
    ctx.setLineDash([]);

    ctx.fillStyle = '#f43f5e';
    ctx.font = '10px monospace';
    ctx.fillText('Thermal Throttle Threshold (75°C)', 10, y75 - 4);

    // Target Temperature limit 68°C for Brownian DVFS
    const y68 = height - ((68 - 20) / (85 - 20)) * height;
    ctx.strokeStyle = 'rgba(245, 158, 11, 0.4)';
    ctx.setLineDash([2, 2]);
    ctx.beginPath();
    ctx.moveTo(0, y68);
    ctx.lineTo(width, y68);
    ctx.stroke();
    ctx.setLineDash([]);

    ctx.fillStyle = '#f59e0b';
    ctx.fillText('Brownian Target Max (68°C)', width - 160, y68 - 4);

    const stepX = width / (history.length - 1);

    // Draw Reactive Temperature Line (Rose / Red)
    ctx.beginPath();
    ctx.strokeStyle = '#f43f5e';
    ctx.lineWidth = 2;
    history.forEach((item, idx) => {
      const x = idx * stepX;
      const y = height - ((item.tempReactive - 20) / (85 - 20)) * height;
      if (idx === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();

    // Draw Brownian Temperature Line (Emerald / Amber)
    ctx.beginPath();
    ctx.strokeStyle = '#10b981';
    ctx.lineWidth = 2.5;
    history.forEach((item, idx) => {
      const x = idx * stepX;
      const y = height - ((item.tempBrownian - 20) / (85 - 20)) * height;
      if (idx === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();

    // Draw Frequency Bars / Lines
    ctx.beginPath();
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.5)';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([3, 3]);
    history.forEach((item, idx) => {
      const x = idx * stepX;
      const y = height - (item.freqBrownian / 4.5) * (height * 0.4);
      if (idx === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();
    ctx.setLineDash([]);
  }, [history]);

  // Render Die Heatmap Visualizer
  useEffect(() => {
    const canvas = dieCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    const currentTemp = history.length > 0
      ? (params.mode === 'brownian' ? history[history.length - 1].tempBrownian : history[history.length - 1].tempReactive)
      : params.ambientTemp;

    ctx.fillStyle = '#020617';
    ctx.fillRect(0, 0, width, height);

    // Silicon Die Frame
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 2;
    ctx.strokeRect(10, 10, width - 20, height - 20);

    // Heat Gradient Center
    const tempRatio = Math.min(1.0, Math.max(0, (currentTemp - 25) / 55));
    const gradient = ctx.createRadialGradient(
      width / 2, height / 2, 5,
      width / 2, height / 2, width / 2.2
    );

    if (tempRatio > 0.75) {
      gradient.addColorStop(0, 'rgba(244, 63, 94, 0.85)'); // Hot Red
      gradient.addColorStop(0.5, 'rgba(245, 158, 11, 0.5)');
      gradient.addColorStop(1, 'rgba(15, 23, 42, 0.2)');
    } else if (tempRatio > 0.4) {
      gradient.addColorStop(0, 'rgba(245, 158, 11, 0.8)'); // Warm Amber
      gradient.addColorStop(0.6, 'rgba(16, 185, 129, 0.3)');
      gradient.addColorStop(1, 'rgba(15, 23, 42, 0.2)');
    } else {
      gradient.addColorStop(0, 'rgba(16, 185, 129, 0.8)'); // Cool Emerald
      gradient.addColorStop(1, 'rgba(15, 23, 42, 0.2)');
    }

    ctx.fillStyle = gradient;
    ctx.fillRect(10, 10, width - 20, height - 20);

    // Sub-blocks on SoC Die
    const blocks = [
      { label: 'CPU Core 0', x: 25, y: 25, w: 70, h: 45 },
      { label: 'CPU Core 1', x: 105, y: 25, w: 70, h: 45 },
      { label: 'GPU Cluster', x: 25, y: 80, w: 150, h: 55 },
      { label: 'Brownian DVFS', x: 185, y: 25, w: 70, h: 110 },
    ];

    blocks.forEach((b) => {
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.25)';
      ctx.strokeRect(b.x, b.y, b.w, b.h);
      ctx.fillStyle = '#ffffff';
      ctx.font = '9px monospace';
      ctx.fillText(b.label, b.x + 5, b.y + 15);
    });

    ctx.fillStyle = '#f8fafc';
    ctx.font = 'bold 12px monospace';
    ctx.fillText(`Die 溫度: ${currentTemp.toFixed(1)}°C`, 20, height - 18);
  }, [history, params.mode, params.ambientTemp]);

  const latest = history.length > 0 ? history[history.length - 1] : null;
  const throttledCountReactive = history.filter((x) => x.throttledReactive).length;
  const throttledCountBrownian = history.filter((x) => x.throttledBrownian).length;

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg relative overflow-hidden">
        <div className="absolute -right-10 -bottom-10 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-amber-950 text-amber-300 border border-amber-800">
                動態電壓頻率調整 DVFS
              </span>
              <span className="text-xs text-slate-400 font-mono">brownian_energy_timewindow().consumed</span>
            </div>
            <h2 className="text-lg font-bold text-slate-100 font-mono">
              預判性布朗熱噪訊能窗 DVFS 控制 (Proactive Brownian DVFS)
            </h2>
            <p className="text-xs text-slate-300 leading-relaxed max-w-3xl">
              傳統 DVFS 屬於「後知後覺」反應型，待晶片溫度突破 <code className="text-rose-400 font-mono font-bold bg-slate-800 px-1 py-0.5 rounded">75°C</code> 後劇烈降頻，造成手機遊戲影格率抖動 (FPS Drop)。<code className="text-amber-300 font-mono font-bold bg-slate-800 px-1 py-0.5 rounded">brownian_energy_timewindow</code> 在晶片微觀熱噪訊發生前，於指定時間視窗內預測功耗趨勢並平滑微調電壓，實現零降頻卡頓。
            </p>
          </div>

          <div className="flex items-center space-x-3 bg-slate-950/80 p-3 rounded-xl border border-slate-800 shrink-0">
            <div className="text-right font-mono">
              <div className="text-xs text-slate-400">熱降頻事件減少 (Throttle Avoided)</div>
              <div className="text-xl font-black text-amber-400">
                {Math.max(0, throttledCountReactive - throttledCountBrownian)} 次
              </div>
            </div>
            <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Real-time Timeline Chart & Heatmap */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Activity className="w-4 h-4 text-amber-400" />
                <h3 className="text-sm font-bold text-slate-200 font-mono">
                  即時晶片溫度與頻率動態走勢 (Temperature & Frequency Timeline)
                </h3>
              </div>
              <div className="flex items-center space-x-3 text-xs font-mono">
                <span className="flex items-center space-x-1 text-rose-400">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block" />
                  <span>傳統反應型 DVFS</span>
                </span>
                <span className="flex items-center space-x-1 text-emerald-400">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block" />
                  <span>布朗能窗預判型</span>
                </span>
              </div>
            </div>

            {/* Timeline Canvas */}
            <div className="relative rounded-xl overflow-hidden border border-slate-800 bg-slate-950">
              <canvas
                ref={chartCanvasRef}
                width={600}
                height={260}
                className="w-full h-[260px] object-contain block"
              />
            </div>

            {/* Real-time Telemetry Bar */}
            <div className="grid grid-cols-4 gap-2 pt-1 font-mono text-xs">
              <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                <div className="text-[10px] text-slate-400">傳統溫度 (Reactive)</div>
                <div className={`text-sm font-bold ${latest && latest.tempReactive >= 75 ? 'text-rose-400 animate-pulse' : 'text-slate-200'}`}>
                  {latest ? latest.tempReactive.toFixed(1) : params.ambientTemp}°C
                </div>
              </div>

              <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                <div className="text-[10px] text-slate-400">布朗能窗溫度 (Brownian)</div>
                <div className="text-sm font-bold text-emerald-400">
                  {latest ? latest.tempBrownian.toFixed(1) : params.ambientTemp}°C
                </div>
              </div>

              <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                <div className="text-[10px] text-slate-400">即時主頻 (Frequency)</div>
                <div className="text-sm font-bold text-sky-400">
                  {latest ? latest.freqBrownian.toFixed(2) : 4.2} GHz
                </div>
              </div>

              <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                <div className="text-[10px] text-slate-400">影格穩定度 (Stability)</div>
                <div className="text-sm font-bold text-amber-400">
                  {params.mode === 'brownian' ? '98.5% (極平滑)' : '72.0% (頻繁抖動)'}
                </div>
              </div>
            </div>
          </div>

          {/* Silicon Die Heatmap Visualizer */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-2">
              <h4 className="text-xs font-bold text-slate-300 font-mono flex items-center space-x-1.5">
                <Flame className="w-4 h-4 text-rose-400" />
                <span>GAAFET 晶片微觀熱分布熱圖 (SoC Die Thermal Map)</span>
              </h4>
              <div className="rounded-xl overflow-hidden border border-slate-800 bg-slate-950">
                <canvas
                  ref={dieCanvasRef}
                  width={280}
                  height={150}
                  className="w-full h-[150px] object-contain block"
                />
              </div>
            </div>

            {/* Performance Mode Comparison Box */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-3 font-mono text-xs">
              <h4 className="text-xs font-bold text-slate-300 flex items-center space-x-1.5">
                <Zap className="w-4 h-4 text-amber-400" />
                <span>模擬演算法模式 (Simulation Mode)</span>
              </h4>

              <div className="space-y-2">
                <button
                  onClick={() => onChange({ ...params, mode: 'brownian' })}
                  className={`w-full p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                    params.mode === 'brownian'
                      ? 'bg-amber-500/20 border-amber-500/50 text-amber-200 shadow-md'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <div className="font-bold text-xs flex items-center justify-between">
                    <span>• 布朗能窗 DVFS (brownian_energy)</span>
                    <span className="text-[10px] bg-amber-950 text-amber-300 px-1.5 py-0.5 rounded">推薦</span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1">
                    於 <code className="text-amber-300">{params.timeWindowMs}ms</code> 能窗內預判熱熵，提早調降 Vdd。
                  </div>
                </button>

                <button
                  onClick={() => onChange({ ...params, mode: 'reactive' })}
                  className={`w-full p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                    params.mode === 'reactive'
                      ? 'bg-rose-500/20 border-rose-500/50 text-rose-200 shadow-md'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <div className="font-bold text-xs">
                    • 傳統反應型熱保護 (Reactive Throttling)
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1">
                    溫度達到 75°C 硬降頻至 2.0GHz，導致大幅度效能卡頓。
                  </div>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Parameter Sliders & Workload Selectors */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-5">
            <div className="border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-slate-100 font-mono flex items-center space-x-2">
                <Zap className="w-4 h-4 text-amber-400" />
                <span>Brownian Power & Thermal Controls</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">功耗預判時間視窗與 FET 熱噪訊參數設定</p>
            </div>

            {/* Time Window slider */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-xs font-mono">
                <span className="text-slate-300 font-semibold">布朗能窗時間 (time_window)</span>
                <span className="text-amber-400 font-bold bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                  {params.timeWindowMs} ms
                </span>
              </div>
              <input
                type="range"
                min={1}
                max={20}
                step={1}
                value={params.timeWindowMs}
                onChange={(e) => onChange({ ...params, timeWindowMs: Number(e.target.value) })}
                className="w-full accent-amber-400 bg-slate-800 h-2 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>1ms (高頻採樣 High Rate)</span>
                <span>20ms (長效能窗 Extended)</span>
              </div>
            </div>

            {/* Energy Budget Slider */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-xs font-mono">
                <span className="text-slate-300">預期能量消耗上限 (Energy Budget)</span>
                <span className="text-slate-100">{params.energyBudgetMw} mW</span>
              </div>
              <input
                type="range"
                min={200}
                max={2000}
                step={50}
                value={params.energyBudgetMw}
                onChange={(e) => onChange({ ...params, energyBudgetMw: Number(e.target.value) })}
                className="w-full accent-amber-400 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
              />
            </div>

            {/* Thermal Noise Variance */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-xs font-mono">
                <span className="text-slate-300">熱噪訊方差 (Thermal Noise Variance σ²)</span>
                <span className="text-slate-100">σ² = {params.noiseVariance.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min={0.05}
                max={1.0}
                step={0.05}
                value={params.noiseVariance}
                onChange={(e) => onChange({ ...params, noiseVariance: Number(e.target.value) })}
                className="w-full accent-amber-400 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
              />
            </div>

            {/* Ambient Temperature */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-xs font-mono">
                <span className="text-slate-300">環境溫度 (Ambient Temp)</span>
                <span className="text-slate-100">{params.ambientTemp} °C</span>
              </div>
              <input
                type="range"
                min={15}
                max={45}
                step={1}
                value={params.ambientTemp}
                onChange={(e) => onChange({ ...params, ambientTemp: Number(e.target.value) })}
                className="w-full accent-amber-400 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
              />
            </div>

            {/* Workload Pattern Selector */}
            <div className="space-y-2 pt-2 border-t border-slate-800">
              <label className="text-xs font-bold text-slate-300 font-mono">
                手機運算負載型態 (Workload Pattern)
              </label>
              <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                {[
                  { id: 'gaming', label: '🎮 3D 遊戲 (Gaming)' },
                  { id: 'ai_inference', label: '🧠 端側 AI (NPU GenAI)' },
                  { id: 'burst', label: '⚡ 突發負載 (Burst)' },
                  { id: 'sustained', label: '🔥 持續跑分 (Sustained)' },
                ].map((pattern) => (
                  <button
                    key={pattern.id}
                    onClick={() => onChange({ ...params, workloadPattern: pattern.id as any })}
                    className={`p-2 rounded-lg border transition-all text-left cursor-pointer ${
                      params.workloadPattern === pattern.id
                        ? 'bg-amber-500/20 border-amber-500/60 text-amber-200 font-bold'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {pattern.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Feature Summary */}
            <div className="bg-slate-950/80 p-3.5 rounded-xl border border-slate-800 space-y-2 text-xs">
              <div className="font-bold text-slate-200 font-mono flex items-center space-x-1.5">
                <CheckCircle2 className="w-4 h-4 text-amber-400" />
                <span>brownian_energy 功耗控制效益</span>
              </div>
              <ul className="text-slate-400 space-y-1 text-[11px] list-disc list-inside">
                <li>於 FET 熱噪訊擴散前精準預判電壓需求。</li>
                <li>避免硬降頻產生的畫面驟卡 (Lag Spikes)。</li>
                <li>提升手機晶片長續航能源轉換效率高達 24%。</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
