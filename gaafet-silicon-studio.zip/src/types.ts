export type TabType = 'layout' | 'power' | 'signal' | 'overview';

export interface LayoutParams {
  routingAngle: number; // 0 (orthogonal) to 45 (log_45-degree)
  gatePitch: number; // 18nm to 30nm
  nanosheetLayers: number; // 2 to 5 sheets
  dielectricConstant: number; // Low-k dielectric, e.g. 2.1 to 3.9
  metalSpacing: number; // 12nm to 24nm
  wireLengthMicrons: number; // 10 to 1000 um
  operatingVoltage: number; // 0.55V to 0.95V
  operatingFreqGHz: number; // 2.0 to 4.5 GHz
}

export interface PowerParams {
  mode: 'reactive' | 'brownian';
  timeWindowMs: number; // 1ms to 20ms
  energyBudgetMw: number; // 100mW to 2000mW
  noiseVariance: number; // 0.1 to 1.0 (thermal fluctuation noise)
  ambientTemp: number; // 25°C to 45°C
  thermalMass: number; // thermal capacitance coefficient
  workloadPattern: 'burst' | 'gaming' | 'ai_inference' | 'sustained';
}

export interface SignalParams {
  amPmCorrection: boolean;
  carrierFreqGHz: number; // 5.8 GHz (Wi-Fi 7) or 28 GHz (5G mmWave)
  modulation: 'QAM-64' | 'QAM-256' | 'QAM-1024' | 'QAM-4096';
  paInputPowerDbm: number; // -10 dBm to +15 dBm
  nonLinearityCoeff: number; // AM-PM phase distortion gain factor
  noiseFloorDbm: number; // -95 dBm to -80 dBm
}

export interface ChipPreset {
  id: string;
  name: string;
  badge: string;
  description: string;
  layout: LayoutParams;
  power: PowerParams;
  signal: SignalParams;
}
