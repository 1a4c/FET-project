import React, { useState } from 'react';
import { TabType, ChipPreset, LayoutParams, PowerParams, SignalParams } from './types';
import { CHIP_PRESETS } from './data/presets';
import { Header } from './components/Header';
import { LayoutTab } from './components/LayoutTab';
import { PowerTab } from './components/PowerTab';
import { SignalTab } from './components/SignalTab';
import { OverviewTab } from './components/OverviewTab';
import { AiAnalysisModal } from './components/AiAnalysisModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('layout');
  const [selectedPreset, setSelectedPreset] = useState<ChipPreset>(CHIP_PRESETS[0]);

  // Active Parameters
  const [layoutParams, setLayoutParams] = useState<LayoutParams>(CHIP_PRESETS[0].layout);
  const [powerParams, setPowerParams] = useState<PowerParams>(CHIP_PRESETS[0].power);
  const [signalParams, setSignalParams] = useState<SignalParams>(CHIP_PRESETS[0].signal);

  // AI Modal
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);
  const [aiReport, setAiReport] = useState<string | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);

  // Handle Preset Select
  const handleSelectPreset = (preset: ChipPreset) => {
    setSelectedPreset(preset);
    setLayoutParams(preset.layout);
    setPowerParams(preset.power);
    setSignalParams(preset.signal);
  };

  // Run AI Analysis
  const handleRunAiAnalysis = async () => {
    setIsAiModalOpen(true);
    setIsAiLoading(true);
    setAiReport(null);

    try {
      const response = await fetch('/api/analyze-silicon', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          layoutParams,
          powerParams,
          signalParams,
          mode: activeTab,
        }),
      });

      const data = await response.json();
      if (data.success) {
        setAiReport(data.report);
      } else {
        setAiReport(`分析失敗：${data.error || '無法取得 AI 診斷數據'}`);
      }
    } catch (err: any) {
      setAiReport(`系統錯誤：${err.message || '連線至 AI 診斷伺服器發生異常'}`);
    } finally {
      setIsAiLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-slate-950">
      {/* Header Bar */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        selectedPreset={selectedPreset}
        onSelectPreset={handleSelectPreset}
        onRunAiAnalysis={handleRunAiAnalysis}
        isAiLoading={isAiLoading}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'layout' && (
          <LayoutTab params={layoutParams} onChange={setLayoutParams} />
        )}

        {activeTab === 'power' && (
          <PowerTab params={powerParams} onChange={setPowerParams} />
        )}

        {activeTab === 'signal' && (
          <SignalTab params={signalParams} onChange={setSignalParams} />
        )}

        {activeTab === 'overview' && (
          <OverviewTab
            layout={layoutParams}
            power={powerParams}
            signal={signalParams}
            preset={selectedPreset}
            onRunAiAnalysis={handleRunAiAnalysis}
            isAiLoading={isAiLoading}
          />
        )}
      </main>

      {/* AI Analysis Diagnostic Modal */}
      <AiAnalysisModal
        isOpen={isAiModalOpen}
        onClose={() => setIsAiModalOpen(false)}
        report={aiReport}
        isLoading={isAiLoading}
      />

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-4 text-center text-xs font-mono text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div>
            GAAFET Silicon Studio &copy; {new Date().getFullYear()} — 2nm GAAFET Standard Cell, Brownian DVFS & RF AM-PM Explorer
          </div>
          <div className="flex items-center space-x-3 text-[11px] text-slate-400">
            <span>log_45-degree (對角佈局)</span>
            <span>•</span>
            <span>brownian_energy (布朗能窗)</span>
            <span>•</span>
            <span>AM-PM.shift (相位修正)</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
