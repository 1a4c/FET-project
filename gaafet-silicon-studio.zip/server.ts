import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

let aiClient: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is not configured.");
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// Health check endpoint
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Silicon Engineering AI Physical Verification & Optimization Advisor
app.post("/api/analyze-silicon", async (req, res) => {
  try {
    const { layoutParams, powerParams, signalParams, mode } = req.body;

    const ai = getAiClient();

    const prompt = `You are a Principal Silicon Architect and Physical Verification Engineer specializing in advanced 2nm GAAFET (Gate-All-Around) smartphone SoC design.

Analyze the following simulation telemetry and parameters from the 3 core silicon pillars:

1. [結構佈局 Structural Layout - log_45-degree]
- Metal Routing Angle: ${layoutParams?.routingAngle ?? 45}° (${layoutParams?.routingAngle === 45 ? "Diagonal log_45-degree" : "Traditional 90° Orthogonal"})
- Gate Pitch: ${layoutParams?.gatePitch ?? 22} nm
- Parasitic Capacitance (C_parasitic): ${layoutParams?.parasiticCap ?? 0.12} fF/μm
- RC Delay (tau): ${layoutParams?.rcDelay ?? 1.85} ps
- Dynamic Switching Power Reduction: ${layoutParams?.powerSavings ?? 18}%

2. [功耗管理 Power Management - brownian_energy_timewindow().consumed]
- DVFS Controller Mode: ${powerParams?.mode ?? "Brownian Predictive DVFS"}
- Brownian Energy Window (t_window): ${powerParams?.timeWindow ?? 5} ms
- Brownian Noise Variance (sigma^2): ${powerParams?.noiseVar ?? 0.35}
- Peak Die Temperature: ${powerParams?.peakTemp ?? 62.4}°C
- Thermal Throttling Events Avoided: ${powerParams?.throttlesAvoided ?? 12}
- Power Efficiency Gain: ${powerParams?.efficiencyGain ?? 24}%

3. [訊號完整性 Signal Integrity - AM-PM.shift]
- Modulation: ${signalParams?.modulation ?? "QAM-4096 (Wi-Fi 7 / 5G)"}
- AM-PM Phase Shift Correction: ${signalParams?.amPmCorrection ? "ACTIVE (Digital Pre-Distortion / FET Bias Compensation)" : "DISABLED"}
- Phase Shift Error (Delta Phi): ${signalParams?.phaseShift ?? 1.2}°
- EVM (Error Vector Magnitude): ${signalParams?.evmDb ?? -38.5} dB (${signalParams?.evmPct ?? 1.18}%)
- Max Upload Speed Impact: ${signalParams?.uploadSpeed ?? 5.8} Gbps

Analysis Task Mode: "${mode || "comprehensive"}"

Please generate a professional, structured Silicon Engineering Diagnostics Report in Chinese (Traditional / 繁體中文) with technical clarity.
Structure your response into:
1. 綜合 PPA (Power, Performance, Area) 評估: Summarize how the combined 45-degree cell routing, Brownian predictive power management, and AM-PM phase shift correction optimize the 2nm GAAFET smartphone chip.
2. 物理驗證與寄生電容分析 (Layout & Parasitics): Deep dive into the parasitic capacitance reduction from 45-degree routing and its impact on clock network distribution & EM noise.
3. 熱噪訊與 DVFS 預判控制 (Thermal & Power): Evaluate how the Brownian thermal noise energy window prevents thermal throttling compared to traditional reactive thermal algorithms.
4. RF 高頻訊號相位修正與 EVM (Signal Integrity): Assess how AM-PM shift compensation boosts 5G sub-6/mmWave & Wi-Fi 7 upload throughput and EVM margin.
5. 晶片架構優化建議 (Actionable Architecture Recommendations): Provide 3 specific microarchitecture parameter tuning recommendations.

Keep it structured, insightful, and formatted with clean markdown with bold metrics.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
    });

    const report = response.text || "無法生成晶片診斷報告。";
    res.json({ success: true, report });
  } catch (error: any) {
    console.error("Gemini silicon analysis error:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Failed to analyze silicon design parameters.",
    });
  }
});

// Vite & Static file handling
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`GAAFET Silicon Studio Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
