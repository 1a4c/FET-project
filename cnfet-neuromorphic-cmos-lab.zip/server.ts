import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-initialize Gemini API to prevent app crash if GEMINI_API_KEY is missing
let aiClient: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey && apiKey !== "MY_GEMINI_API_KEY") {
      aiClient = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });
    }
  }
  return aiClient;
}

// API Routes
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", time: new Date().toISOString() });
});

// Endpoint for the AI Semiconductor Consultant
app.post("/api/gemini/consult", async (req, res) => {
  const { question, systemState } = req.body;

  if (!question) {
    res.status(400).json({ error: "Question parameter is required" });
    return;
  }

  const ai = getGeminiClient();
  if (!ai) {
    // Graceful fallback when API key is missing
    res.json({
      answer: `[Simulated Local Engine] (Configure GEMINI_API_KEY in Settings > Secrets for advanced insights)

Based on your current device parameters:
- **FET Gate Control**: Threshold $V_{th} = ${systemState?.fet?.thresholdVoltage || 1.5}V$
- **CNFET Material**: ${systemState?.cnfet?.material?.toUpperCase() || 'SWCNT'} (Mobility: ${systemState?.cnfet?.mobility || 1200} cm²/V-s)
- **FeFET Synaptic Weight**: $W = ${systemState?.synapse?.weight?.toFixed(2) || 0.5}$
- **Power Gating State**: ${systemState?.power?.powerGatingState || 'active'}

Your question: "${question}"

*Architectural Recommendation*: 
Increasing the gate voltage of the CNFET beyond the channel threshold allows high-speed charge carrier conduction ($~${systemState?.cnfet?.switchingFrequency || 10} GHz$). In neuromorphic synaptic computing, utilizing SWCNTs as the high-mobility channel reduces the RC time delay of synaptic weight changes, which can be modeled through the FeFET's continuous ferroelectric polarization hysteresis loop. This reduces power dissipation from ${systemState?.cnfet?.powerDissipation || 45} µW to minimal leakage levels under intermittent standby.`,
      isSimulated: true,
    });
    return;
  }

  try {
    const prompt = `You are an elite Semiconductor Physicist and Solid-State Device Engineer specializing in next-generation Field-Effect Transistors (FETs).
You are analyzing a complex integrated system characterized by:
1. Carbon Nanotube Field-Effect Transistors (CNFET) for high-mobility channels.
2. CMOS Active Pixel Sensors (CIS) with MOSFET buffers and readout.
3. Ferroelectric Synaptic Transistors (FeFET) simulating continuous synaptic weights for neuromorphic computing.
4. PLC-triggered gate control switching logic.
5. High-frequency Power MOSFETs in intermittent energy harvesting systems.

The user's current simulation system state is:
${JSON.stringify(systemState, null, 2)}

The user asks: "${question}"

Provide a highly technical, rigorous, yet accessible explanation (with clean formatting, mathematical formulas if relevant, and professional device architecture advice) responding to their query in Traditional Chinese (繁體中文). Do not use placeholders; explain the physical mechanism (e.g., threshold voltage shift, channel carrier transport, polarization state, or standby power gating leakage).`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
    });

    res.json({
      answer: response.text,
      isSimulated: false,
    });
  } catch (error: any) {
    console.error("Gemini Consultation Error:", error);
    res.status(500).json({
      error: "Error communicating with Gemini API",
      message: error.message || String(error),
    });
  }
});

// Setup Vite Dev server middleware or static assets
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
