export interface FETParams {
  gateVoltage: number; // V_G (0 to 5V)
  sourceDrainVoltage: number; // V_DS (0 to 5V)
  thresholdVoltage: number; // V_th (1.5V)
  isPlcTriggered: boolean;
  channelState: 'cut-off' | 'saturation' | 'linear';
}

export interface CNFETParams {
  material: 'swcnt' | 'mwcnt' | 'graphene';
  chirality: string; // e.g., "(10,0)" metallic vs "(10,3)" semiconducting
  mobility: number; // cm^2 / V-s
  carrierDensity: number; // per um
  switchingFrequency: number; // GHz
  powerDissipation: number; // uW
}

export interface CISParams {
  pixelGrid: number[][]; // 4x4 grayscale values
  selectedPixel: { x: number; y: number } | null;
  sensorFeedback: string;
  isScanning: boolean;
}

export interface SynapseParams {
  weight: number; // conductance (0 to 1)
  polarization: number; // ferroelectric polarization state (-1 to +1)
  pulseHistory: { type: 'potentiation' | 'depression'; time: number; weight: number }[];
  isTraining: boolean;
}

export interface PowerParams {
  powerSupplyStable: boolean;
  inputVoltage: number; // V
  leakageCurrent: number; // nA
  harvestedEnergy: number; // uW
  queueStatus: string[];
  powerGatingState: 'active' | 'sleep' | 'standby';
}

export interface SimulationState {
  fet: FETParams;
  cnfet: CNFETParams;
  cis: CISParams;
  synapse: SynapseParams;
  power: PowerParams;
  systemIntegrator: {
    isRunning: boolean;
    clockSpeed: number; // MHz
    temperature: number; // °C
    totalPower: number; // mW
    inferenceAccuracy: number; // %
  };
}
