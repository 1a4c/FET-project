import React, { useState } from 'react';
import { SimulationState } from '../types';
import { Bot, Send, HelpCircle, Loader2, Sparkles } from 'lucide-react';

interface AIConsultantProps {
  systemState: SimulationState;
}

export default function AIConsultant({ systemState }: AIConsultantProps) {
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [loading, setLoading] = useState(false);

  const presetQuestions = [
    '碳奈米管 (CNFET) 作為溝道，如何提升載子遷移率與 CMOS 開關效率？',
    'FeFET 鐵電極化狀態如何模擬突觸權重，並實現大腦類神經硬體學習？',
    '間歇供電系統中，功率 MOSFET 如何透過低漏電 (Off-leakage) 確保待機省電？',
    '3T Active Pixel Sensor 中，MOSFET 如何對 CMOS 影像訊號進行放大緩衝？'
  ];

  const handleAsk = async (queryText: string) => {
    if (!queryText.trim() || loading) return;

    setLoading(true);
    setAnswer('');
    try {
      const response = await fetch('/api/gemini/consult', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          question: queryText,
          systemState,
        }),
      });

      const data = await response.json();
      if (data.answer) {
        setAnswer(data.answer);
      } else if (data.error) {
        setAnswer(`Error: ${data.error}. ${data.message || ''}`);
      }
    } catch (err: any) {
      console.error(err);
      setAnswer('連線到 AI 半導體顧問時發生錯誤，請稍後再試。');
    } finally {
      setLoading(false);
    }
  };

  // Basic renderer to convert markdown headers, list points and bold text safely
  const renderMarkdownText = (text: string) => {
    return text.split('\n').map((line, index) => {
      let trimmed = line.trim();

      // Headers
      if (trimmed.startsWith('###')) {
        return <h4 key={index} className="text-sm font-bold text-cyber-cyan mt-3 mb-1 font-mono">{trimmed.replace('###', '')}</h4>;
      }
      if (trimmed.startsWith('##')) {
        return <h3 key={index} className="text-base font-bold text-cyber-cyan mt-4 mb-2 border-b border-slate-800 pb-1 font-mono">{trimmed.replace('##', '')}</h3>;
      }
      if (trimmed.startsWith('#')) {
        return <h2 key={index} className="text-lg font-bold text-cyber-cyan mt-5 mb-3 font-mono">{trimmed.replace('#', '')}</h2>;
      }

      // Bullet points
      if (trimmed.startsWith('-') || trimmed.startsWith('*')) {
        const item = trimmed.substring(1).trim();
        return (
          <li key={index} className="ml-4 list-disc text-slate-300 text-xs my-1 leading-relaxed">
            {renderBoldText(item)}
          </li>
        );
      }

      // Plain line with potential bold elements
      if (trimmed === '') {
        return <div key={index} className="h-2" />;
      }

      return <p key={index} className="text-slate-300 text-xs my-1.5 leading-relaxed">{renderBoldText(trimmed)}</p>;
    });
  };

  const renderBoldText = (text: string) => {
    const parts = text.split('**');
    return parts.map((part, idx) => {
      if (idx % 2 === 1) {
        return <strong key={idx} className="text-cyber-cyan font-bold">{part}</strong>;
      }
      return part;
    });
  };

  return (
    <div id="ai-consultant" className="bg-cyber-card border border-slate-800 rounded-xl p-5 flex flex-col h-full shadow-lg">
      <div className="flex items-center gap-2 mb-4">
        <div className="p-1.5 bg-cyber-pink/10 border border-cyber-pink/20 rounded text-cyber-pink glow-pink">
          <Bot className="w-5 h-5" />
        </div>
        <div>
          <h3 className="text-sm font-bold text-slate-100 flex items-center gap-1.5 font-mono">
            AI 半導體架構顧問 <span className="text-[10px] bg-cyber-cyan/15 border border-cyber-cyan/20 text-cyber-cyan px-2 py-0.5 rounded-full">Gemini 3.5</span>
          </h3>
          <p className="text-[10px] text-slate-400">固態物理與晶片架構設計即時問答</p>
        </div>
      </div>

      {/* Answer Output View */}
      <div className="flex-1 bg-slate-950/60 border border-slate-800/80 rounded-lg p-3.5 overflow-y-auto mb-4 min-h-[180px] max-h-[350px]">
        {loading ? (
          <div className="h-full flex flex-col items-center justify-center text-slate-400 space-y-2 py-8">
            <Loader2 className="w-6 h-6 text-cyber-cyan animate-spin" />
            <span className="text-xs font-mono">正在分析晶片狀態與物理機制...</span>
          </div>
        ) : answer ? (
          <div className="space-y-1 text-xs">
            {renderMarkdownText(answer)}
          </div>
        ) : (
          <div className="h-full flex flex-col items-center justify-center text-slate-500 text-center py-8">
            <Sparkles className="w-8 h-8 text-slate-700 mb-2" />
            <p className="text-xs">
              在下方輸入或點選關於 **CNFET、CMOS 影像感測、類神經 FeFET 或功率開關** 的問題，AI 顧問將結合目前晶片參數進行深度分析。
            </p>
          </div>
        )}
      </div>

      {/* Preset Suggestions */}
      <div className="mb-4">
        <span className="text-[10px] font-mono text-slate-500 uppercase block mb-1.5 flex items-center gap-1">
          <HelpCircle className="w-3.5 h-3.5" />
          建議探索問題：
        </span>
        <div className="grid grid-cols-1 gap-1.5">
          {presetQuestions.map((q, idx) => (
            <button
              key={idx}
              onClick={() => {
                setQuestion(q);
                handleAsk(q);
              }}
              className="text-[11px] text-left text-slate-300 hover:text-cyber-cyan bg-slate-900/60 hover:bg-slate-950 border border-slate-800 hover:border-cyber-cyan/30 p-2 rounded transition-all truncate"
            >
              {q}
            </button>
          ))}
        </div>
      </div>

      {/* User Input Form */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleAsk(question);
        }}
        className="flex gap-2"
      >
        <input
          type="text"
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          placeholder="詢問 AI 關於極化、載子遷移、功率閘控問題..."
          className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-cyber-cyan focus:ring-1 focus:ring-cyber-cyan/30 placeholder-slate-600"
        />
        <button
          type="submit"
          disabled={loading || !question.trim()}
          className="bg-cyber-cyan hover:bg-cyber-cyan/85 text-slate-950 px-3 py-2 rounded-lg font-semibold text-xs flex items-center justify-center gap-1 transition-all disabled:opacity-40 disabled:cursor-not-allowed shrink-0"
        >
          <Send className="w-3.5 h-3.5" />
          諮詢
        </button>
      </form>
    </div>
  );
}
