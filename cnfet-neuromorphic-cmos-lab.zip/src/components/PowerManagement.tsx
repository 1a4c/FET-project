import React, { useState, useEffect, useRef } from 'react';
import { PowerParams } from '../types';
import { Shield, Sparkles, Battery, RefreshCw, AlertCircle, Play } from 'lucide-react';

interface PowerManagementProps {
  state: PowerParams;
  onChange: (updates: Partial<PowerParams>) => void;
}

export default function PowerManagement({ state, onChange }: PowerManagementProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animFrameRef = useRef<number | null>(null);
  const timeRef = useRef<number>(0);

  // Power gating state machine
  useEffect(() => {
    let harvestedEnergy = state.harvestedEnergy;
    let powerGatingState: 'active' | 'sleep' | 'standby' = 'active';
    let leakageCurrent = 1.2; // nA in active
    let inputVoltage = 1.8;

    if (!state.powerSupplyStable) {
      // Simulate energy harvesting fluctuations
      const cycle = Math.sin(timeRef.current * 0.4) * 0.5 + 0.5; // [0, 1] wave
      harvestedEnergy = parseFloat((cycle * 60).toFixed(1)); // fluctuate [0, 60] uW

      if (harvestedEnergy < 12) {
        powerGatingState = 'sleep';
        leakageCurrent = 0.005; // Extremely low leakage under sleep (sub-threshold power gated)
        inputVoltage = 0.1;
      } else if (harvestedEnergy < 30) {
        powerGatingState = 'standby';
        leakageCurrent = 0.3;
        inputVoltage = 0.9;
      } else {
        powerGatingState = 'active';
        leakageCurrent = 1.5;
        inputVoltage = 1.8;
      }
    } else {
      harvestedEnergy = 50;
      powerGatingState = 'active';
      leakageCurrent = 1.4;
      inputVoltage = 1.8;
    }

    // Task queue logic depending on state
    let queueStatus = [...state.queueStatus];
    if (powerGatingState === 'sleep') {
      if (!queueStatus.includes('Task: CMOS Image Frame Scan')) {
        queueStatus = ['Task: CMOS Image Frame Scan', 'Task: Neuromorphic Synapse Weight Calc', 'Task: PLC State Feedback'];
      }
    } else {
      if (queueStatus.length > 0) {
        // Process tasks sequentially
        if (Math.random() < 0.15) {
          queueStatus.shift();
        }
      }
    }

    onChange({
      harvestedEnergy,
      powerGatingState,
      leakageCurrent,
      inputVoltage,
      queueStatus,
    });
  }, [state.powerSupplyStable, timeRef.current]);

  // Render harvested energy waves
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    const draw = () => {
      ctx.clearRect(0, 0, width, height);
      timeRef.current += 0.05;

      // Axis lines
      ctx.strokeStyle = '#1e293b';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(10, height / 2);
      ctx.lineTo(width - 10, height / 2);
      ctx.stroke();

      // Energy wave path
      ctx.strokeStyle = state.powerSupplyStable ? '#00f0ff' : '#eab308';
      ctx.lineWidth = 2;
      ctx.beginPath();

      const waveLength = width - 20;
      for (let i = 0; i < waveLength; i++) {
        const x = i + 10;
        let y = height / 2;

        if (state.powerSupplyStable) {
          // Flat stable supply
          y += Math.sin(i * 0.1 + timeRef.current * 2) * 2;
        } else {
          // High-frequency small fluctuations + massive underlying low-frequency wave
          const baseFluctuation = Math.sin((i - timeRef.current * 10) * 0.03) * 25;
          const noise = Math.sin(i * 0.2 + timeRef.current * 4) * 3;
          y += baseFluctuation + noise;
        }

        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      // Current power level dot
      const currentX = width / 2;
      let currentY = height / 2;
      if (state.powerSupplyStable) {
        currentY += Math.sin(currentX * 0.1 + timeRef.current * 2) * 2;
      } else {
        const baseFluctuation = Math.sin((currentX - timeRef.current * 10) * 0.03) * 25;
        const noise = Math.sin(currentX * 0.2 + timeRef.current * 4) * 3;
        currentY += baseFluctuation + noise;
      }

      ctx.fillStyle = '#ff007f';
      ctx.beginPath();
      ctx.arc(currentX, currentY, 5, 0, Math.PI * 2);
      ctx.fill();

      // Annotations
      ctx.font = '9px monospace';
      ctx.fillStyle = '#64748b';
      ctx.fillText('Harvested Energy Curve (間歇性能源曲線)', 15, 20);

      animFrameRef.current = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [state.powerSupplyStable]);

  const getPowerGatingBadgeStyle = () => {
    switch (state.powerGatingState) {
      case 'sleep':
        return 'bg-cyber-pink/20 border-cyber-pink/50 text-cyber-pink animate-pulse';
      case 'standby':
        return 'bg-cyber-amber/20 border-cyber-amber/50 text-cyber-amber';
      default:
        return 'bg-cyber-green/20 border-cyber-green/50 text-cyber-green';
    }
  };

  const getPowerGatingText = () => {
    switch (state.powerGatingState) {
      case 'sleep': return '深度睡眠 (Sleep - 閘極切斷/超低漏電)';
      case 'standby': return '待機 (Standby - 低電壓保持)';
      default: return '完全工作 (Active - 高能效運算)';
    }
  };

  return (
    <div id="power-management" className="bg-cyber-card border border-slate-800 rounded-xl p-5 flex flex-col h-full">
      <div className="flex justify-between items-start mb-3">
        <div>
          <span className="text-xs font-mono text-cyber-cyan tracking-wider uppercase block">Concept 5</span>
          <h3 className="text-lg font-semibold text-slate-100 flex items-center gap-1.5">
            功率管理與間歇性能源
          </h3>
          <p className="text-xs text-slate-400">Power MOSFET Gating & Intermittent Systems</p>
        </div>
        <button
          onClick={() => onChange({ powerSupplyStable: !state.powerSupplyStable })}
          className={`flex items-center gap-1 text-xs px-2.5 py-1 rounded-md border transition-all ${
            !state.powerSupplyStable
              ? 'bg-cyber-amber/20 border-cyber-amber/50 text-cyber-amber shadow-sm'
              : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          {!state.powerSupplyStable ? '間歇性能源' : '穩定直流供電'}
        </button>
      </div>

      <div className="relative border border-slate-800 bg-slate-950/60 rounded-lg overflow-hidden flex-1 min-h-[140px] flex items-center justify-center">
        <canvas ref={canvasRef} width={380} height={140} className="w-full h-full object-contain" />
      </div>

      <div className="mt-4 space-y-3 font-mono">
        {/* Dynamic State Badge */}
        <div className={`border p-2 rounded-lg text-center text-xs font-semibold flex items-center justify-center gap-1.5 ${getPowerGatingBadgeStyle()}`}>
          <Battery className="w-4 h-4" />
          PMIC 模式: {getPowerGatingText()}
        </div>

        {/* Dynamic metrics */}
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="bg-slate-950/40 p-2 border border-slate-800 rounded">
            <span className="text-slate-400">收集功率 Harvested</span>
            <div className="text-base font-bold text-cyber-cyan mt-0.5">{state.harvestedEnergy} µW</div>
          </div>
          <div className="bg-slate-950/40 p-2 border border-slate-800 rounded">
            <span className="text-slate-400">漏電流 Off-Leakage</span>
            <div className={`text-base font-bold mt-0.5 ${state.powerGatingState === 'sleep' ? 'text-cyber-green' : 'text-cyber-pink'}`}>
              {state.leakageCurrent} nA
            </div>
          </div>
        </div>

        {/* Task Queue Monitor */}
        <div className="bg-slate-950 p-2.5 border border-slate-800 rounded-md">
          <div className="flex justify-between items-center text-[10px] text-slate-500 uppercase tracking-wider mb-1.5">
            <span>任務排隊緩衝 system_id_queue</span>
            {state.queueStatus.length > 0 && (
              <span className="flex items-center gap-0.5 text-cyber-amber text-[9px] animate-pulse">
                <AlertCircle className="w-3 h-3" />
                供電不足，掛起排隊
              </span>
            )}
          </div>
          {state.queueStatus.length === 0 ? (
            <div className="text-cyber-green text-xs flex items-center gap-1.5 py-1">
              <span className="w-1.5 h-1.5 bg-cyber-green rounded-full animate-ping" />
              無任務掛起 (系統正常低能效調度中)
            </div>
          ) : (
            <div className="space-y-1">
              {state.queueStatus.slice(0, 2).map((task, i) => (
                <div key={i} className="text-[10px] text-slate-300 bg-slate-900 border border-slate-800/80 px-2 py-1 rounded flex justify-between items-center">
                  <span className="truncate">{task}</span>
                  <span className="text-cyber-amber font-semibold shrink-0">WAITING</span>
                </div>
              ))}
              {state.queueStatus.length > 2 && (
                <div className="text-[9px] text-slate-500 text-center">
                  + {state.queueStatus.length - 2} 個其它底層掛起任務
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
