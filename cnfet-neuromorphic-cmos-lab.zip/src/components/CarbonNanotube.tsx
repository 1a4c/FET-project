import React, { useEffect, useRef } from 'react';
import { CNFETParams } from '../types';
import { Layers, Activity, ShieldAlert, Cpu } from 'lucide-react';

interface CarbonNanotubeProps {
  state: CNFETParams;
  onChange: (updates: Partial<CNFETParams>) => void;
}

export default function CarbonNanotube({ state, onChange }: CarbonNanotubeProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animFrameRef = useRef<number | null>(null);
  const timeRef = useRef<number>(0);

  // Auto-calculate switching metrics based on material parameters and slider settings
  useEffect(() => {
    let mobility = 1200;
    let frequency = 12.5;
    let power = 45;

    if (state.material === 'swcnt') {
      if (state.chirality === '(10,3) Semiconducting') {
        mobility = 2800;
        frequency = 35.8;
        power = 18.2;
      } else {
        // Metallic
        mobility = 4200;
        frequency = 5.2; // behaving like a wire, low switching frequency gating
        power = 95.0; // high loss due to high leakage
      }
    } else if (state.material === 'mwcnt') {
      mobility = 1100;
      frequency = 15.0;
      power = 32.5;
    } else if (state.material === 'graphene') {
      mobility = 7500;
      frequency = 92.4;
      power = 115.4; // very high mobility but high static leakage
    }

    if (mobility !== state.mobility || frequency !== state.switchingFrequency || power !== state.powerDissipation) {
      onChange({
        mobility,
        switchingFrequency: frequency,
        powerDissipation: power
      });
    }
  }, [state.material, state.chirality]);

  // Render nanotube lattice/particles
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    const draw = () => {
      ctx.clearRect(0, 0, width, height);
      timeRef.current += 0.03;

      // Draw channel walls/boundaries
      ctx.strokeStyle = 'rgba(71, 85, 105, 0.4)';
      ctx.setLineDash([5, 5]);
      ctx.beginPath();
      ctx.moveTo(0, 40);
      ctx.lineTo(width, 40);
      ctx.moveTo(0, height - 40);
      ctx.lineTo(width, height - 40);
      ctx.stroke();
      ctx.setLineDash([]);

      const speedFactor = state.mobility / 1000;

      if (state.material === 'swcnt' || state.material === 'mwcnt') {
        // Render Carbon Nanotube cylinders with honeycomb mesh simulation
        const centerY = height / 2;
        const radius = state.material === 'swcnt' ? 30 : 42;

        // Background lines of the cylinder
        ctx.strokeStyle = 'rgba(0, 240, 255, 0.15)';
        ctx.lineWidth = 1;

        // Draw multiple rings of nanotube
        const numRings = 12;
        for (let r = 0; r < numRings; r++) {
          const x = (r / (numRings - 1)) * (width - 40) + 20;

          // Draw vertical ellipse slices
          ctx.beginPath();
          ctx.ellipse(x, centerY, radius / 2, radius, 0, 0, Math.PI * 2);
          ctx.stroke();

          // Connect rings to form a honeycomb mesh
          if (r < numRings - 1) {
            const nextX = ((r + 1) / (numRings - 1)) * (width - 40) + 20;
            ctx.strokeStyle = 'rgba(0, 240, 255, 0.2)';
            for (let angle = 0; angle < Math.PI * 2; angle += Math.PI / 4) {
              const offsetAngle = angle + (r % 2 === 0 ? 0.2 : -0.2);
              const y1 = centerY + Math.sin(angle) * radius;
              const y2 = centerY + Math.sin(offsetAngle) * radius;
              ctx.beginPath();
              ctx.moveTo(x, y1);
              ctx.lineTo(nextX, y2);
              ctx.stroke();
            }
          }
        }

        // Draw inner concentric ring for Multi-Walled CNT
        if (state.material === 'mwcnt') {
          ctx.strokeStyle = 'rgba(168, 85, 247, 0.2)';
          const innerRadius = 20;
          for (let r = 0; r < numRings; r++) {
            const x = (r / (numRings - 1)) * (width - 40) + 20;
            ctx.beginPath();
            ctx.ellipse(x, centerY, innerRadius / 2, innerRadius, 0, 0, Math.PI * 2);
            ctx.stroke();
          }
        }

        // Animated High Mobility Carriers (Electron wave packets)
        ctx.fillStyle = state.material === 'swcnt' ? '#00f0ff' : '#a855f7';
        const numCarriers = 15;
        for (let i = 0; i < numCarriers; i++) {
          const progress = ((i / numCarriers) + (timeRef.current * 0.1 * speedFactor)) % 1;
          const x = 20 + progress * (width - 40);
          const angle = (i * (Math.PI / 3) + timeRef.current) % (Math.PI * 2);
          const y = centerY + Math.sin(angle) * radius;

          // Only show carrier on the "foreground" half of the cylinder for 3D depth
          if (Math.cos(angle) >= 0) {
            ctx.beginPath();
            ctx.arc(x, y, 3, 0, Math.PI * 2);
            ctx.fill();

            // Glow tail
            ctx.fillStyle = state.material === 'swcnt' ? 'rgba(0, 240, 255, 0.15)' : 'rgba(168, 85, 247, 0.15)';
            ctx.beginPath();
            ctx.arc(x - (10 * speedFactor), y, 5, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = state.material === 'swcnt' ? '#00f0ff' : '#a855f7';
          }
        }
      } else {
        // Graphene honeycomb flat sheet
        ctx.strokeStyle = 'rgba(57, 255, 20, 0.15)';
        ctx.lineWidth = 1;

        const rowCount = 6;
        const colCount = 14;
        const size = 16;

        for (let r = 0; r < rowCount; r++) {
          for (let c = 0; c < colCount; c++) {
            const x = c * size * 1.5 + 20;
            const y = r * size * Math.sqrt(3) + 30 + (c % 2 === 0 ? 0 : (size * Math.sqrt(3)) / 2);

            // Draw a single hexagon
            ctx.beginPath();
            for (let side = 0; side < 6; side++) {
              const angle = (side * Math.PI) / 3;
              ctx.lineTo(x + size * Math.cos(angle), y + size * Math.sin(angle));
            }
            ctx.closePath();
            ctx.stroke();
          }
        }

        // Draw super fast ballistic carriers
        ctx.fillStyle = '#39ff14';
        const numCarriers = 20;
        for (let i = 0; i < numCarriers; i++) {
          const progress = ((i / numCarriers) + (timeRef.current * 0.18 * speedFactor)) % 1;
          const x = 20 + progress * (width - 40);
          // Scatter carriers slightly over sheet paths
          const offsetIndex = Math.floor((i + Math.floor(timeRef.current)) % rowCount);
          const y = 30 + offsetIndex * size * Math.sqrt(3) + Math.sin(timeRef.current * 2 + i) * 6;

          ctx.beginPath();
          ctx.arc(x, y, 2.5, 0, Math.PI * 2);
          ctx.fill();

          ctx.fillStyle = 'rgba(57, 255, 20, 0.2)';
          ctx.beginPath();
          ctx.arc(x - 8, y, 4.5, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#39ff14';
        }
      }

      ctx.font = '10px monospace';
      ctx.fillStyle = '#94a3b8';
      ctx.fillText(`Lattice: ${state.material.toUpperCase()} Bi-carbon Structure`, 15, 25);

      animFrameRef.current = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [state.material, state.chirality, state.mobility]);

  return (
    <div id="carbon-nanotube" className="bg-cyber-card border border-slate-800 rounded-xl p-5 flex flex-col h-full">
      <div>
        <span className="text-xs font-mono text-cyber-cyan tracking-wider uppercase block">Concept 2</span>
        <h3 className="text-lg font-semibold text-slate-100 flex items-center gap-1.5">
          碳基電子學與奈米溝道
        </h3>
        <p className="text-xs text-slate-400">Carbon Nanotubes & Graphene High-Mobility Channel</p>
      </div>

      <div className="relative mt-3 border border-slate-800 bg-slate-950/60 rounded-lg overflow-hidden flex-1 min-h-[170px] flex items-center justify-center">
        <canvas ref={canvasRef} width={380} height={180} className="w-full h-full object-contain" />
      </div>

      <div className="mt-4 grid grid-cols-2 gap-2 text-xs font-mono">
        <div className="bg-slate-950/40 p-2 border border-slate-800/60 rounded-md">
          <div className="text-slate-400">載子遷移率 Carrier Mobility</div>
          <div className="text-cyber-cyan text-base font-bold mt-1">
            {state.mobility.toLocaleString()} <span className="text-xs font-medium">cm²/V-s</span>
          </div>
        </div>
        <div className="bg-slate-950/40 p-2 border border-slate-800/60 rounded-md">
          <div className="text-slate-400">頻率上限 Max Switch Freq</div>
          <div className="text-cyber-green text-base font-bold mt-1">
            {state.switchingFrequency.toFixed(1)} <span className="text-xs font-medium">GHz</span>
          </div>
        </div>
        <div className="bg-slate-950/40 p-2 border border-slate-800/60 rounded-md col-span-2 flex justify-between items-center">
          <span className="text-slate-400">功耗 Power Dissipation</span>
          <span className="text-cyber-pink font-bold text-base">
            {state.powerDissipation.toFixed(1)} <span className="text-xs font-medium">µW</span>
          </span>
        </div>
      </div>

      {/* Selector Controls */}
      <div className="mt-3 space-y-2.5">
        <div className="flex gap-2">
          {(['swcnt', 'mwcnt', 'graphene'] as const).map((mat) => (
            <button
              key={mat}
              onClick={() => {
                onChange({
                  material: mat,
                  chirality: mat === 'swcnt' ? '(10,3) Semiconducting' : ''
                });
              }}
              className={`flex-1 text-xs py-1 px-1.5 rounded border transition-all uppercase font-mono ${
                state.material === mat
                  ? 'bg-cyber-cyan/15 border-cyber-cyan text-cyber-cyan shadow-sm shadow-cyber-cyan/15'
                  : 'bg-slate-800/50 border-slate-700 text-slate-400 hover:text-slate-200'
              }`}
            >
              {mat === 'swcnt' ? '單壁 CNT' : mat === 'mwcnt' ? '多壁 CNT' : '石墨烯'}
            </button>
          ))}
        </div>

        {state.material === 'swcnt' && (
          <div className="flex justify-between items-center bg-slate-950/40 p-1.5 border border-slate-800 rounded-md">
            <span className="text-xs font-mono text-slate-400">Chirality (螺旋性)</span>
            <div className="flex gap-1.5">
              {(['(10,3) Semiconducting', '(10,0) Metallic'] as const).map((ch) => (
                <button
                  key={ch}
                  onClick={() => onChange({ chirality: ch })}
                  className={`text-[10px] px-2 py-0.5 rounded border transition-all ${
                    state.chirality === ch
                      ? 'bg-cyber-cyan/15 border-cyber-cyan/50 text-cyber-cyan'
                      : 'bg-slate-800/40 border-slate-700 text-slate-400'
                  }`}
                >
                  {ch.split(' ')[0]} {ch.includes('Semiconducting') ? '半導體' : '金屬'}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
