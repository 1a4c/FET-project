import React, { useEffect } from 'react';
import { CISParams } from '../types';
import { Camera, RefreshCw, Zap, Sliders } from 'lucide-react';

interface ImageSensorProps {
  state: CISParams;
  onChange: (updates: Partial<CISParams>) => void;
}

export default function ImageSensor({ state, onChange }: ImageSensorProps) {
  // Set default pixel selection if empty
  useEffect(() => {
    if (state.selectedPixel === null) {
      onChange({ selectedPixel: { x: 1, y: 1 } });
    }
  }, []);

  const handlePixelClick = (x: number, y: number) => {
    // Toggle brightness level: 0 -> 80 -> 160 -> 240 -> 0
    const newGrid = state.pixelGrid.map((row) => [...row]);
    const currentVal = newGrid[y][x];
    let newVal = 0;
    if (currentVal === 0) newVal = 80;
    else if (currentVal === 80) newVal = 160;
    else if (currentVal === 160) newVal = 240;
    else newVal = 0;

    newGrid[y][x] = newVal;

    // Calculate feedback voltage level
    const voltageFeedback = (newVal / 255) * 3.3; // CIS output voltage max 3.3V
    const feedback_attribute = `Pixel (${x},${y}) Photocharge: ${newVal}e- / Readout Amplified Voltage: ${voltageFeedback.toFixed(2)}V`;

    onChange({
      pixelGrid: newGrid,
      selectedPixel: { x, y },
      sensorFeedback: feedback_attribute,
    });
  };

  const triggerScan = () => {
    onChange({ isScanning: true });
    let step = 0;
    const interval = setInterval(() => {
      const x = step % 4;
      const y = Math.floor(step / 4);

      if (step >= 16) {
        clearInterval(interval);
        onChange({ isScanning: false });
        return;
      }

      const chargeVal = state.pixelGrid[y][x];
      const voltage = (chargeVal / 255) * 3.3;
      const feedback_attribute = `[SCANNING] Grid (${x},${y}) -> MOSFET Source-Follower output: ${voltage.toFixed(2)}V`;

      onChange({
        selectedPixel: { x, y },
        sensorFeedback: feedback_attribute,
      });

      step++;
    }, 150);
  };

  const getSelectedPixelVoltage = () => {
    if (!state.selectedPixel) return 0;
    const { x, y } = state.selectedPixel;
    const charge = state.pixelGrid[y][x];
    return (charge / 255) * 3.3;
  };

  const selectedPixelCharge = state.selectedPixel
    ? state.pixelGrid[state.selectedPixel.y][state.selectedPixel.x]
    : 0;

  return (
    <div id="image-sensor" className="bg-cyber-card border border-slate-800 rounded-xl p-5 flex flex-col h-full">
      <div className="flex justify-between items-start mb-3">
        <div>
          <span className="text-xs font-mono text-cyber-cyan tracking-wider uppercase block">Concept 3</span>
          <h3 className="text-lg font-semibold text-slate-100 flex items-center gap-1.5">
            CMOS 影像感測與回饋
          </h3>
          <p className="text-xs text-slate-400">CMOS Active Pixel Sensor CIS & Feedback Attribute</p>
        </div>
        <button
          onClick={triggerScan}
          disabled={state.isScanning}
          className={`flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-md border transition-all ${
            state.isScanning
              ? 'bg-cyber-green/20 border-cyber-green/50 text-cyber-green animate-pulse'
              : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
          }`}
        >
          <Camera className="w-3.5 h-3.5" />
          {state.isScanning ? '陣列掃描中...' : '進行光學掃描'}
        </button>
      </div>

      <div className="grid grid-cols-2 gap-4 flex-1">
        {/* Pixel Array Matrix */}
        <div className="flex flex-col justify-center items-center">
          <div className="text-xs font-mono text-slate-400 mb-2">4x4 感測陣列 (像素點擊可調整光強)</div>
          <div className="grid grid-cols-4 gap-1.5 p-2 bg-slate-950/40 border border-slate-800/80 rounded-lg">
            {state.pixelGrid.map((row, y) =>
              row.map((val, x) => {
                const isSelected = state.selectedPixel?.x === x && state.selectedPixel?.y === y;
                return (
                  <button
                    key={`${x}-${y}`}
                    onClick={() => handlePixelClick(x, y)}
                    style={{
                      backgroundColor: `rgb(${val + 15}, ${val + 20}, ${val + 35})`,
                    }}
                    className={`w-11 h-11 rounded-md border transition-all flex flex-col justify-between p-1 text-[8px] font-mono ${
                      isSelected
                        ? 'border-cyber-cyan shadow-[0_0_8px_rgba(0,240,255,0.4)] ring-1 ring-cyber-cyan/50 scale-105'
                        : val > 0
                        ? 'border-slate-600 text-slate-300'
                        : 'border-slate-800 text-slate-500'
                    }`}
                  >
                    <span className="opacity-50">({x},{y})</span>
                    <span className="font-bold text-center w-full block">{(val / 255 * 100).toFixed(0)}%</span>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* 3T Circuit & Buffer Readout */}
        <div className="flex flex-col justify-center text-xs space-y-2 border-l border-slate-800/60 pl-4 font-mono">
          <div className="text-xs text-slate-300 font-semibold mb-1 flex items-center gap-1">
            <Sliders className="w-3.5 h-3.5 text-cyber-cyan" />
            3T Pixel 訊號放大電路
          </div>

          <div className="bg-slate-950/50 p-2 border border-slate-800 rounded-md space-y-1.5 text-[11px]">
            <div className="flex justify-between">
              <span className="text-slate-400">光電二極體 Charge</span>
              <span className="text-cyber-amber font-bold">{selectedPixelCharge} e-</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">1. RST (復位閘極)</span>
              <span className="text-slate-500 text-[10px] bg-slate-800 px-1.5 py-0.2 rounded">關閉 (偵測期)</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">2. SF (源極跟隨放大)</span>
              <span className="text-cyber-green text-[10px] bg-cyber-green/10 border border-cyber-green/20 px-1.5 py-0.2 rounded">
                緩衝放大中
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">3. SEL (像素選通閘)</span>
              <span className="text-cyber-cyan text-[10px] bg-cyber-cyan/10 border border-cyber-cyan/20 px-1.5 py-0.2 rounded">
                選通輸出
              </span>
            </div>
          </div>

          <div className="bg-slate-950 p-2.5 border border-slate-800 rounded-md">
            <div className="text-[10px] text-slate-500 uppercase tracking-wider mb-1">
              鏡像採樣輸出 cv2_scanned.feedback_attribute
            </div>
            <div className="text-cyber-cyan font-mono text-[11px] leading-relaxed break-words">
              {state.sensorFeedback || "點擊像素點或點擊光學掃描以獲取回饋信號..."}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
