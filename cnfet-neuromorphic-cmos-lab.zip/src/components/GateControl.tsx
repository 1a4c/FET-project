import React, { useEffect, useRef } from 'react';
import { FETParams } from '../types';
import { ToggleLeft, ToggleRight, Zap, RefreshCw } from 'lucide-react';

interface GateControlProps {
  state: FETParams;
  onChange: (updates: Partial<FETParams>) => void;
}

export default function GateControl({ state, onChange }: GateControlProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number | null>(null);
  const particleOffsetRef = useRef<number>(0);

  // Determine current channel state based on VG
  useEffect(() => {
    let channelState: 'cut-off' | 'saturation' | 'linear' = 'cut-off';
    if (state.gateVoltage >= state.thresholdVoltage) {
      if (state.sourceDrainVoltage < state.gateVoltage - state.thresholdVoltage) {
        channelState = 'linear';
      } else {
        channelState = 'saturation';
      }
    } else {
      channelState = 'cut-off';
    }
    if (channelState !== state.channelState) {
      onChange({ channelState });
    }
  }, [state.gateVoltage, state.sourceDrainVoltage, state.thresholdVoltage, state.channelState]);

  // PLC High-frequency pulse simulation
  useEffect(() => {
    let interval: any = null;
    if (state.isPlcTriggered) {
      let isHigh = false;
      interval = setInterval(() => {
        isHigh = !isHigh;
        onChange({ gateVoltage: isHigh ? 4.2 : 0.2 });
      }, 300); // 300ms switching frequency
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [state.isPlcTriggered]);

  // Draw FET and carrier simulation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    const draw = () => {
      ctx.clearRect(0, 0, width, height);

      // Draw background Grid
      ctx.strokeStyle = 'rgba(30, 41, 59, 0.5)';
      ctx.lineWidth = 1;
      const gridSize = 20;
      for (let x = 0; x < width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Draw Substrate (p-Silicon)
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(40, 110, width - 80, 80);
      ctx.strokeStyle = '#475569';
      ctx.strokeRect(40, 110, width - 80, 80);
      ctx.fillStyle = '#94a3b8';
      ctx.font = '10px monospace';
      ctx.fillText('p-Silicon Substrate', width / 2 - 50, 160);

      // Draw Source (n+)
      ctx.fillStyle = '#0f766e';
      ctx.fillRect(40, 110, 60, 40);
      ctx.strokeRect(40, 110, 60, 40);
      ctx.fillStyle = '#e2e8f0';
      ctx.fillText('Source (n+)', 45, 135);

      // Draw Drain (n+)
      ctx.fillStyle = '#0f766e';
      ctx.fillRect(width - 100, 110, 60, 40);
      ctx.strokeRect(width - 100, 110, 60, 40);
      ctx.fillStyle = '#e2e8f0';
      ctx.fillText('Drain (n+)', width - 95, 135);

      // Draw Dielectric (SiO2 Oxide Layer)
      ctx.fillStyle = '#3f6212';
      ctx.fillRect(100, 100, width - 200, 10);
      ctx.strokeRect(100, 100, width - 200, 10);
      ctx.fillStyle = '#a3e635';
      ctx.fillText('SiO2 Oxide Layer', width / 2 - 45, 95);

      // Draw Gate Metal
      ctx.fillStyle = '#1e40af';
      ctx.fillRect(120, 70, width - 240, 30);
      ctx.strokeRect(120, 70, width - 240, 30);
      ctx.fillStyle = '#00f0ff';
      ctx.fillText('Gate (Polysilicon)', width / 2 - 45, 88);

      // Draw Gate Electric Field lines if Gate is high
      if (state.gateVoltage > 0.1) {
        ctx.strokeStyle = `rgba(0, 240, 255, ${Math.min(1, state.gateVoltage / 5)})`;
        ctx.lineWidth = 2;
        const gateLeft = 120;
        const gateWidth = width - 240;
        for (let i = 1; i < 6; i++) {
          const x = gateLeft + (gateWidth / 6) * i;
          ctx.beginPath();
          ctx.moveTo(x, 100);
          ctx.lineTo(x, 110);
          ctx.stroke();
        }
      }

      // Channel (Inversion Layer) Color based on State
      const hasChannel = state.gateVoltage >= state.thresholdVoltage;
      if (hasChannel) {
        const alpha = Math.min(1, (state.gateVoltage - state.thresholdVoltage) / 3.5);
        // Saturation has high current pinch-off, linear is continuous
        const grad = ctx.createLinearGradient(100, 110, width - 100, 110);
        grad.addColorStop(0, `rgba(0, 240, 255, ${alpha})`);
        if (state.channelState === 'saturation') {
          // Pinch-off near the drain
          grad.addColorStop(0.7, `rgba(0, 240, 255, ${alpha})`);
          grad.addColorStop(1, `rgba(0, 240, 255, ${alpha * 0.15})`);
        } else {
          grad.addColorStop(1, `rgba(0, 240, 255, ${alpha})`);
        }
        ctx.fillStyle = grad;
        ctx.fillRect(100, 110, width - 200, 10);

        ctx.fillStyle = '#00f0ff';
        ctx.fillText('Inversion Channel', width / 2 - 45, 125);
      } else {
        // No channel (cut-off)
        ctx.fillStyle = 'rgba(71, 85, 105, 0.2)';
        ctx.fillRect(100, 110, width - 200, 10);
        ctx.fillStyle = '#94a3b8';
        ctx.fillText('Channel Cut-off (0)', width / 2 - 45, 125);
      }

      // Carrier transport animation
      if (hasChannel && state.sourceDrainVoltage > 0.1) {
        // Electrons flow from source (left) to drain (right)
        // Current flows from drain to source
        particleOffsetRef.current += (state.sourceDrainVoltage * 1.5 + 1);
        if (particleOffsetRef.current > 40) {
          particleOffsetRef.current = 0;
        }

        ctx.fillStyle = '#39ff14';
        const startX = 100;
        const endX = width - 100;
        const channelY = 115;
        const channelWidth = endX - startX;

        for (let i = 0; i < 8; i++) {
          const x = startX + ((i * 40 + particleOffsetRef.current) % channelWidth);
          // If in saturation state, particles fade/disappear near the pinch-off drain
          if (state.channelState === 'saturation' && x > startX + channelWidth * 0.85) {
            continue;
          }
          ctx.beginPath();
          ctx.arc(x, channelY, 3, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // Annotations
      ctx.fillStyle = '#e2e8f0';
      ctx.font = '9px monospace';
      ctx.fillText(`VG = ${state.gateVoltage.toFixed(2)}V`, width / 2 - 25, 45);
      ctx.fillText(`VDS = ${state.sourceDrainVoltage.toFixed(2)}V`, width - 85, 185);
      ctx.fillText(`Vth = ${state.thresholdVoltage.toFixed(2)}V`, 45, 185);

      animationFrameRef.current = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    };
  }, [state]);

  const getStateColor = () => {
    switch (state.channelState) {
      case 'linear': return 'text-cyber-green border-cyber-green/30 bg-cyber-green/5';
      case 'saturation': return 'text-cyber-cyan border-cyber-cyan/30 bg-cyber-cyan/5';
      default: return 'text-slate-400 border-slate-700 bg-slate-800/20';
    }
  };

  const getShorthandDesc = () => {
    switch (state.channelState) {
      case 'linear': return '線性導通區 (Linear - 開關已開/電阻元件)';
      case 'saturation': return '飽和夾斷區 (Saturation - 開關已開/定電流源)';
      default: return '截止區 (Cut-off - 開關已關/阻斷邏輯 0)';
    }
  };

  return (
    <div id="gate-control" className="bg-cyber-card border border-slate-800 rounded-xl p-5 flex flex-col h-full">
      <div className="flex justify-between items-start mb-3">
        <div>
          <span className="text-xs font-mono text-cyber-cyan tracking-wider uppercase block">Concept 1</span>
          <h3 className="text-lg font-semibold text-slate-100 flex items-center gap-1.5">
            閘極控制與開關邏輯
          </h3>
          <p className="text-xs text-slate-400">Junction Mode & PLC Triggered</p>
        </div>
        <button
          onClick={() => onChange({ isPlcTriggered: !state.isPlcTriggered })}
          className={`flex items-center gap-1 text-xs px-2.5 py-1 rounded-md border transition-all ${
            state.isPlcTriggered
              ? 'bg-cyber-pink/20 border-cyber-pink/50 text-cyber-pink shadow-md shadow-cyber-pink/10 animate-pulse'
              : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
          }`}
        >
          <Zap className="w-3.5 h-3.5" />
          {state.isPlcTriggered ? 'PLC 觸發中' : '啟動 PLC 觸發'}
        </button>
      </div>

      <div className="relative border border-slate-800 bg-slate-950/60 rounded-lg overflow-hidden flex-1 min-h-[190px] flex items-center justify-center">
        <canvas ref={canvasRef} width={380} height={200} className="w-full h-full object-contain" />
      </div>

      <div className="mt-4 space-y-3">
        <div className={`border p-2 rounded-lg text-center text-xs font-mono font-medium transition-all ${getStateColor()}`}>
          目前狀態：{getShorthandDesc()}
        </div>

        {/* Gate Voltage Slider */}
        <div className="space-y-1.5">
          <div className="flex justify-between text-xs font-mono">
            <span className="text-slate-400">閘極電壓 Gate Voltage (VG)</span>
            <span className="text-cyber-cyan font-bold">{state.gateVoltage.toFixed(2)} V</span>
          </div>
          <input
            type="range"
            min="0"
            max="5"
            step="0.05"
            disabled={state.isPlcTriggered}
            value={state.gateVoltage}
            onChange={(e) => onChange({ gateVoltage: parseFloat(e.target.value) })}
            className="w-full accent-cyber-cyan h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer disabled:opacity-40"
          />
        </div>

        {/* Source-Drain Voltage Slider */}
        <div className="space-y-1.5">
          <div className="flex justify-between text-xs font-mono">
            <span className="text-slate-400">漏源電壓 Source-Drain (VDS)</span>
            <span className="text-cyber-green font-bold">{state.sourceDrainVoltage.toFixed(2)} V</span>
          </div>
          <input
            type="range"
            min="0"
            max="5"
            step="0.1"
            value={state.sourceDrainVoltage}
            onChange={(e) => onChange({ sourceDrainVoltage: parseFloat(e.target.value) })}
            className="w-full accent-cyber-green h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer"
          />
        </div>
      </div>
    </div>
  );
}
