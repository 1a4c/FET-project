import React, { useState, useEffect, useRef } from 'react';
import { SynapseParams } from '../types';
import { BrainCircuit, RotateCcw, Award, CheckCircle } from 'lucide-react';

interface NeuromorphicProps {
  state: SynapseParams;
  onChange: (updates: Partial<SynapseParams>) => void;
}

export default function Neuromorphic({ state, onChange }: NeuromorphicProps) {
  const [pattern, setPattern] = useState<boolean[]>([
    false, true, false,
    true, true, true,
    false, true, false
  ]); // A cross pattern
  const targetPattern = [
    false, true, false,
    true, true, true,
    false, true, false
  ];

  const handlePotentiation = () => {
    // Increase polarization and weight
    const newWeight = Math.min(1.0, state.weight + 0.08);
    const newPolarization = Math.min(1.0, state.polarization + 0.15);
    const pulseHistory = [
      ...state.pulseHistory.slice(-15),
      { type: 'potentiation' as const, time: Date.now(), weight: newWeight }
    ];

    onChange({
      weight: newWeight,
      polarization: newPolarization,
      pulseHistory
    });
  };

  const handleDepression = () => {
    // Decrease polarization and weight
    const newWeight = Math.max(0.02, state.weight - 0.08);
    const newPolarization = Math.max(-1.0, state.polarization - 0.15);
    const pulseHistory = [
      ...state.pulseHistory.slice(-15),
      { type: 'depression' as const, time: Date.now(), weight: newWeight }
    ];

    onChange({
      weight: newWeight,
      polarization: newPolarization,
      pulseHistory
    });
  };

  // Toggle interactive neuromorphic drawing/pattern blocks
  const togglePatternBlock = (index: number) => {
    const newPat = [...pattern];
    newPat[index] = !newPat[index];
    setPattern(newPat);

    // Dynamic conductance modulation mimicking a real synaptic array:
    // More aligned blocks = higher collective synaptic conductance (weight)
    let correctCount = 0;
    for (let i = 0; i < 9; i++) {
      if (newPat[i] === targetPattern[i]) correctCount++;
    }

    const accuracy = correctCount / 9;
    // Modulate FeFET weight based on precision alignment
    const newWeight = 0.1 + accuracy * 0.9;
    const newPolarization = (accuracy * 2) - 1; // Map [0,1] to [-1,1]

    onChange({
      weight: parseFloat(newWeight.toFixed(2)),
      polarization: parseFloat(newPolarization.toFixed(2)),
      pulseHistory: [
        ...state.pulseHistory.slice(-15),
        { type: 'potentiation', time: Date.now(), weight: newWeight }
      ]
    });
  };

  // Compute accuracy match percentage
  let correctCount = 0;
  for (let i = 0; i < 9; i++) {
    if (pattern[i] === targetPattern[i]) correctCount++;
  }
  const matchPercentage = Math.round((correctCount / 9) * 100);

  return (
    <div id="neuromorphic" className="bg-cyber-card border border-slate-800 rounded-xl p-5 flex flex-col h-full">
      <div className="flex justify-between items-start mb-3">
        <div>
          <span className="text-xs font-mono text-cyber-cyan tracking-wider uppercase block">Concept 4</span>
          <h3 className="text-lg font-semibold text-slate-100 flex items-center gap-1.5">
            類神經形態突觸 FeFET
          </h3>
          <p className="text-xs text-slate-400">Neuromorphic Synaptic FeFET & Polarization</p>
        </div>
        <BrainCircuit className="w-5 h-5 text-cyber-pink animate-pulse" />
      </div>

      <div className="grid grid-cols-2 gap-4 flex-1">
        {/* Ferroelectric Polarization Hysteresis (P-V Curve) */}
        <div className="flex flex-col justify-center">
          <div className="text-xs font-mono text-slate-400 mb-1 text-center">FeFET 鐵電極化遲滯迴線</div>
          <div className="relative border border-slate-800/80 bg-slate-950/60 p-2 rounded-lg flex items-center justify-center min-h-[140px]">
            <svg viewBox="0 0 100 100" className="w-full h-28 overflow-visible">
              {/* Grid Lines */}
              <line x1="50" y1="5" x2="50" y2="95" stroke="#1e293b" strokeWidth="1" strokeDasharray="2" />
              <line x1="5" y1="50" x2="95" y2="50" stroke="#1e293b" strokeWidth="1" strokeDasharray="2" />

              {/* Hysteresis Loop Path (S-curve) */}
              {/* Upper curve (remanent polarization positive) */}
              <path
                d="M 10 90 Q 30 70 50 70 T 90 10"
                fill="none"
                stroke="rgba(244, 63, 94, 0.4)"
                strokeWidth="1.5"
              />
              {/* Lower curve (remanent polarization negative) */}
              <path
                d="M 10 90 Q 50 30 70 30 T 90 10"
                fill="none"
                stroke="rgba(0, 240, 255, 0.4)"
                strokeWidth="1.5"
              />

              {/* Current Polarization Point (Animates based on polarization state) */}
              {/* Map polarization [-1, 1] to y-axis [90, 10] */}
              {/* Map weight [0, 1] to x-axis [10, 90] */}
              {(() => {
                const xVal = 10 + state.weight * 80;
                const yVal = 90 - ((state.polarization + 1) / 2) * 80;
                return (
                  <g>
                    <circle cx={xVal} cy={yVal} r="4" fill="#ff007f" className="glow-pink" />
                    <line x1="50" y1="50" x2={xVal} y2={yVal} stroke="#ff007f" strokeWidth="1" strokeDasharray="2" />
                  </g>
                );
              })()}

              {/* Axis Labels */}
              <text x="90" y="46" fill="#64748b" fontSize="5" fontFamily="monospace">+VG</text>
              <text x="2" y="46" fill="#64748b" fontSize="5" fontFamily="monospace">-VG</text>
              <text x="52" y="10" fill="#64748b" fontSize="5" fontFamily="monospace">+P (極化)</text>
              <text x="52" y="95" fill="#64748b" fontSize="5" fontFamily="monospace">-P</text>
            </svg>
          </div>
          <div className="flex gap-1.5 mt-2">
            <button
              onClick={handlePotentiation}
              className="flex-1 text-[10px] font-mono py-1 rounded bg-cyber-pink/15 border border-cyber-pink/30 text-cyber-pink hover:bg-cyber-pink/35"
            >
              增強 (+VG 脈衝)
            </button>
            <button
              onClick={handleDepression}
              className="flex-1 text-[10px] font-mono py-1 rounded bg-cyber-cyan/15 border border-cyber-cyan/30 text-cyber-cyan hover:bg-cyber-cyan/35"
            >
              抑制 (-VG 脈衝)
            </button>
          </div>
        </div>

        {/* Synaptic Memory Matrix */}
        <div className="flex flex-col justify-center text-xs space-y-2 border-l border-slate-800/60 pl-4 font-mono">
          <div className="text-xs text-slate-300 font-semibold mb-1 flex items-center gap-1.5">
            <Award className="w-3.5 h-3.5 text-cyber-amber" />
            突觸權重特徵學習 (3x3 陣列)
          </div>

          <div className="flex items-center gap-3">
            <div className="grid grid-cols-3 gap-1 p-1 bg-slate-950/40 border border-slate-800 rounded">
              {pattern.map((val, idx) => (
                <button
                  key={idx}
                  onClick={() => togglePatternBlock(idx)}
                  className={`w-7 h-7 rounded border transition-all ${
                    val
                      ? 'bg-cyber-pink/80 border-cyber-pink scale-95 shadow-[0_0_6px_rgba(255,0,127,0.3)]'
                      : 'bg-slate-800/30 border-slate-800'
                  }`}
                />
              ))}
            </div>

            <div className="space-y-1 text-[10px] flex-1">
              <span className="text-slate-400 block">目標權重特徵：</span>
              <div className="grid grid-cols-3 gap-[2px] w-12 p-[2px] bg-slate-900 border border-slate-800 rounded">
                {targetPattern.map((val, idx) => (
                  <div
                    key={idx}
                    className={`w-3.5 h-3.5 rounded-[1px] ${val ? 'bg-cyber-cyan/40' : 'bg-slate-950'}`}
                  />
                ))}
              </div>
              <div className="text-cyber-green text-[9px] mt-0.5 flex items-center gap-0.5">
                <CheckCircle className="w-2.5 h-2.5" />
                十字特徵分類器
              </div>
            </div>
          </div>

          <div className="bg-slate-950/50 p-2 border border-slate-800 rounded-md space-y-1.5 text-[11px] mt-1">
            <div className="flex justify-between">
              <span className="text-slate-400">突觸電導率 Weight (W)</span>
              <span className="text-cyber-pink font-bold">{state.weight.toFixed(2)} S</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">鐵電電偶極極化 Polarization</span>
              <span className="text-cyber-cyan font-bold">{state.polarization.toFixed(2)} µC/cm²</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">特徵匹配度 Learning Score</span>
              <span className="text-cyber-amber font-bold">{matchPercentage}%</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
