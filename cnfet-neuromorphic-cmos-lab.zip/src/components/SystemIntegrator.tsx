import React, { useEffect, useState } from 'react';
import { SimulationState } from '../types';
import { Play, Square, Activity, Cpu, Gauge, Thermometer, Battery } from 'lucide-react';

interface SystemIntegratorProps {
  systemState: SimulationState;
  onToggleRun: () => void;
}

export default function SystemIntegrator({ systemState, onToggleRun }: SystemIntegratorProps) {
  const isRunning = systemState.systemIntegrator.isRunning;

  // Derive dynamic total system power and performance metrics based on subsystems
  const calculateSystemMetrics = () => {
    let clockSpeed = 1200; // MHz
    let temperature = 38.5; // °C
    let totalPower = 2.4; // mW
    let accuracy = systemState.systemIntegrator.inferenceAccuracy;

    // 1. CNFET material adjustments
    if (systemState.cnfet.material === 'swcnt') {
      clockSpeed = systemState.cnfet.chirality.includes('Semiconducting') ? 3500 : 500;
      totalPower = systemState.cnfet.chirality.includes('Semiconducting') ? 1.8 : 4.5;
    } else if (systemState.cnfet.material === 'mwcnt') {
      clockSpeed = 1500;
      totalPower = 2.8;
    } else if (systemState.cnfet.material === 'graphene') {
      clockSpeed = 6200;
      totalPower = 6.2;
    }

    // 2. Power state adjustments
    if (systemState.power.powerGatingState === 'sleep') {
      clockSpeed = 0;
      totalPower = 0.05; // leakage only
      temperature = 22.0; // cool down to room temp
    } else if (systemState.power.powerGatingState === 'standby') {
      clockSpeed = 100;
      totalPower = 0.6;
      temperature = 28.0;
    } else {
      // normal operation temperature based on speed
      temperature = parseFloat((30 + (clockSpeed / 1000) * 4.5).toFixed(1));
    }

    // 3. Neuromorphic alignment precision
    // Accuracy is directly coupled with the synaptic matching score
    const correctCount = systemState.synapse.pulseHistory.length;
    // Base alignment is computed
    return {
      clockSpeed,
      temperature,
      totalPower,
    };
  };

  const { clockSpeed, temperature, totalPower } = calculateSystemMetrics();

  // Compute matched percentage for local display
  let pixelCorrect = 0;
  const targetPattern = [
    false, true, false,
    true, true, true,
    false, true, false
  ];
  // Calculate accuracy matching based on FeFET weight
  const systemAccuracy = Math.round(75 + systemState.synapse.weight * 23);

  return (
    <div id="system-integrator" className="bg-slate-900 border border-slate-800/80 rounded-xl p-6 shadow-xl relative overflow-hidden">
      {/* Visual cybernetic energy background */}
      <div className="absolute inset-0 bg-gradient-to-r from-cyan-950/10 via-slate-950/40 to-pink-950/10 pointer-events-none" />

      <div className="relative flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6 pb-4 border-b border-slate-800">
        <div>
          <span className="text-xs font-mono text-cyber-cyan tracking-wider uppercase bg-cyber-cyan/10 border border-cyber-cyan/20 px-2.5 py-0.5 rounded-full inline-block mb-1.5">
            System Pipeline Architecture
          </span>
          <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            碳奈米管類神經 CMOS 整合晶片架構
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-Time CNFET-based Neuromorphic CMOS Sensing & Logic Simulation Pipeline
          </p>
        </div>

        <button
          onClick={onToggleRun}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-semibold tracking-wider transition-all shadow-md ${
            isRunning
              ? 'bg-cyber-pink/20 border border-cyber-pink/50 text-cyber-pink shadow-cyber-pink/10 animate-pulse'
              : 'bg-cyber-cyan border border-cyber-cyan/30 text-slate-950 hover:bg-cyber-cyan/85 shadow-cyber-cyan/20'
          }`}
        >
          {isRunning ? (
            <>
              <Square className="w-4 h-4 fill-current" />
              停止即時整合模擬
            </>
          ) : (
            <>
              <Play className="w-4 h-4 fill-current" />
              啟動全晶片整合模擬
            </>
          )}
        </button>
      </div>

      {/* Dynamic Architecture Flow Pipeline */}
      <div className="relative grid grid-cols-1 md:grid-cols-4 gap-4 p-4 bg-slate-950/60 rounded-xl border border-slate-800/60 mb-6">
        {/* Module A: CIS */}
        <div className="bg-slate-900/80 border border-slate-800 p-3 rounded-lg text-center relative">
          <div className="text-xs font-mono text-cyber-green font-semibold mb-1">CMOS 影像感測 CIS</div>
          <p className="text-[10px] text-slate-400">採集環境光訊號並放大</p>
          <div className="text-[11px] font-mono text-cyber-cyan mt-2 font-bold bg-slate-950/60 py-1 rounded">
            {systemState.cis.selectedPixel
              ? `Pixel (${systemState.cis.selectedPixel.x},${systemState.cis.selectedPixel.y})`
              : 'Idle'}
          </div>
          {isRunning && (
            <div className="absolute -right-3 top-1/2 -translate-y-1/2 z-10 hidden md:block">
              <span className="flex h-2.5 w-2.5 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyber-green opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-cyber-green"></span>
              </span>
            </div>
          )}
        </div>

        {/* Module B: FeFET */}
        <div className="bg-slate-900/80 border border-slate-800 p-3 rounded-lg text-center relative">
          <div className="text-xs font-mono text-cyber-pink font-semibold mb-1">FeFET 類神經突觸</div>
          <p className="text-[10px] text-slate-400">鐵電極化權重特徵推演</p>
          <div className="text-[11px] font-mono text-cyber-pink mt-2 font-bold bg-slate-950/60 py-1 rounded">
            Synapse W: {systemState.synapse.weight.toFixed(2)} S
          </div>
          {isRunning && (
            <div className="absolute -right-3 top-1/2 -translate-y-1/2 z-10 hidden md:block">
              <span className="flex h-2.5 w-2.5 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyber-pink opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-cyber-pink"></span>
              </span>
            </div>
          )}
        </div>

        {/* Module C: CNFET & PLC */}
        <div className="bg-slate-900/80 border border-slate-800 p-3 rounded-lg text-center relative">
          <div className="text-xs font-mono text-cyber-cyan font-semibold mb-1">CNFET 開關 (PLC)</div>
          <p className="text-[10px] text-slate-400">閘極高速截止/導通切換</p>
          <div className="text-[11px] font-mono text-cyber-cyan mt-2 font-bold bg-slate-950/60 py-1 rounded">
            F_max: {systemState.cnfet.switchingFrequency.toFixed(1)} GHz
          </div>
          {isRunning && (
            <div className="absolute -right-3 top-1/2 -translate-y-1/2 z-10 hidden md:block">
              <span className="flex h-2.5 w-2.5 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyber-cyan opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-cyber-cyan"></span>
              </span>
            </div>
          )}
        </div>

        {/* Module D: PMIC */}
        <div className="bg-slate-900/80 border border-slate-800 p-3 rounded-lg text-center relative">
          <div className="text-xs font-mono text-cyber-amber font-semibold mb-1">功率管理 PMIC</div>
          <p className="text-[10px] text-slate-400">間歇防護與低漏電斷路</p>
          <div className="text-[11px] font-mono text-cyber-amber mt-2 font-bold bg-slate-950/60 py-1 rounded">
            Mode: {systemState.power.powerGatingState.toUpperCase()}
          </div>
        </div>
      </div>

      {/* Real-Time Telemetry Monitor */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 font-mono text-xs">
        {/* Core Frequency */}
        <div className="bg-slate-950 p-3 border border-slate-800 rounded-lg flex items-center gap-3">
          <div className="p-2 bg-cyber-cyan/10 border border-cyber-cyan/20 text-cyber-cyan rounded-md">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <span className="text-slate-500 block text-[10px]">晶片工作頻率 Frequency</span>
            <span className="text-base font-bold text-slate-200">
              {isRunning ? (clockSpeed / 1000).toFixed(2) : '0.00'}{' '}
              <span className="text-[10px] text-slate-400 font-medium">GHz</span>
            </span>
          </div>
        </div>

        {/* Inference Accuracy */}
        <div className="bg-slate-950 p-3 border border-slate-800 rounded-lg flex items-center gap-3">
          <div className="p-2 bg-cyber-pink/10 border border-cyber-pink/20 text-cyber-pink rounded-md">
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <span className="text-slate-500 block text-[10px]">類神經辨識率 Accuracy</span>
            <span className="text-base font-bold text-slate-200">
              {isRunning ? systemAccuracy : '0'}{' '}
              <span className="text-[10px] text-slate-400 font-medium">%</span>
            </span>
          </div>
        </div>

        {/* Temperature */}
        <div className="bg-slate-950 p-3 border border-slate-800 rounded-lg flex items-center gap-3">
          <div className="p-2 bg-cyber-amber/10 border border-cyber-amber/20 text-cyber-amber rounded-md">
            <Thermometer className="w-5 h-5" />
          </div>
          <div>
            <span className="text-slate-500 block text-[10px]">核心溫度 Temperature</span>
            <span className="text-base font-bold text-slate-200">
              {isRunning ? temperature.toFixed(1) : '22.0'}{' '}
              <span className="text-[10px] text-slate-400 font-medium">°C</span>
            </span>
          </div>
        </div>

        {/* Total Power */}
        <div className="bg-slate-950 p-3 border border-slate-800 rounded-lg flex items-center gap-3">
          <div className="p-2 bg-cyber-green/10 border border-cyber-green/20 text-cyber-green rounded-md">
            <Battery className="w-5 h-5" />
          </div>
          <div>
            <span className="text-slate-500 block text-[10px]">總體功耗 Power Cons.</span>
            <span className="text-base font-bold text-slate-200">
              {isRunning ? totalPower.toFixed(2) : '0.05'}{' '}
              <span className="text-[10px] text-slate-400 font-medium">mW</span>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
