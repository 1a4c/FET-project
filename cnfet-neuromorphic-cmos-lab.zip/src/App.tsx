import React, { useState, useEffect } from 'react';
import { SimulationState } from './types';
import GateControl from './components/GateControl';
import CarbonNanotube from './components/CarbonNanotube';
import ImageSensor from './components/ImageSensor';
import Neuromorphic from './components/Neuromorphic';
import PowerManagement from './components/PowerManagement';
import SystemIntegrator from './components/SystemIntegrator';
import AIConsultant from './components/AIConsultant';
import { Layers, Activity, Zap, Shield, Cpu, Sparkles } from 'lucide-react';

const INITIAL_STATE: SimulationState = {
  fet: {
    gateVoltage: 0.8,
    sourceDrainVoltage: 1.2,
    thresholdVoltage: 1.5,
    isPlcTriggered: false,
    channelState: 'cut-off',
  },
  cnfet: {
    material: 'swcnt',
    chirality: '(10,3) Semiconducting',
    mobility: 2800,
    carrierDensity: 1.2,
    switchingFrequency: 35.8,
    powerDissipation: 18.2,
  },
  cis: {
    pixelGrid: [
      [80, 0, 160, 0],
      [0, 240, 80, 160],
      [160, 0, 240, 0],
      [80, 160, 0, 240],
    ],
    selectedPixel: { x: 1, y: 1 },
    sensorFeedback: 'Pixel (1,1) Photocharge: 240e- / Readout Amplified Voltage: 3.11V',
    isScanning: false,
  },
  synapse: {
    weight: 0.64,
    polarization: 0.35,
    pulseHistory: [],
    isTraining: false,
  },
  power: {
    powerSupplyStable: false,
    inputVoltage: 1.8,
    leakageCurrent: 1.2,
    harvestedEnergy: 35.0,
    queueStatus: [],
    powerGatingState: 'active',
  },
  systemIntegrator: {
    isRunning: true,
    clockSpeed: 3500,
    temperature: 42.5,
    totalPower: 1.8,
    inferenceAccuracy: 92,
  },
};

export default function App() {
  const [state, setState] = useState<SimulationState>(INITIAL_STATE);

  // Global system runner animation logic
  useEffect(() => {
    let interval: any = null;

    if (state.systemIntegrator.isRunning) {
      let step = 0;
      interval = setInterval(() => {
        step++;

        // 1. Periodically simulate optical scan on CIS (cycling pixel values)
        const nextX = step % 4;
        const nextY = Math.floor((step / 4) % 4);
        const nextVal = state.cis.pixelGrid[nextY][nextX];
        const vOut = (nextVal / 255) * 3.3;

        // 2. Modulate Synapse Weights slightly representing continuous incoming stimuli
        const weightDelta = (Math.sin(step * 0.3) * 0.05);
        const newWeight = Math.min(1.0, Math.max(0.05, state.synapse.weight + weightDelta));
        const newPolarization = Math.min(1.0, Math.max(-1.0, state.synapse.polarization + (weightDelta * 1.5)));

        // 3. Modulate Gate voltage slightly to reflect continuous switches unless PLC triggered
        let newVg = state.fet.gateVoltage;
        if (!state.fet.isPlcTriggered) {
          newVg = parseFloat((1.2 + Math.sin(step * 0.5) * 0.8).toFixed(2));
        }

        // 4. Energy supply waves
        let harvested = state.power.harvestedEnergy;
        if (!state.power.powerSupplyStable) {
          const wave = Math.sin(step * 0.2) * 0.5 + 0.5;
          harvested = parseFloat((wave * 55 + 5).toFixed(1));
        }

        setState((prev) => ({
          ...prev,
          fet: {
            ...prev.fet,
            gateVoltage: newVg,
          },
          cis: {
            ...prev.cis,
            selectedPixel: { x: nextX, y: nextY },
            sensorFeedback: `[AUTO-RUN] Scanning CIS (${nextX},${nextY}) -> Charge: ${nextVal}e- -> SF Gate readout: ${vOut.toFixed(2)}V`,
          },
          synapse: {
            ...prev.synapse,
            weight: parseFloat(newWeight.toFixed(2)),
            polarization: parseFloat(newPolarization.toFixed(2)),
          },
          power: {
            ...prev.power,
            harvestedEnergy: harvested,
          },
        }));
      }, 1000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [state.systemIntegrator.isRunning, state.fet.isPlcTriggered, state.power.powerSupplyStable]);

  // Handle generic state updates for each component
  const updateFet = (updates: Partial<typeof state.fet>) => {
    setState((prev) => ({ ...prev, fet: { ...prev.fet, ...updates } }));
  };

  const updateCnfet = (updates: Partial<typeof state.cnfet>) => {
    setState((prev) => ({ ...prev, cnfet: { ...prev.cnfet, ...updates } }));
  };

  const updateCis = (updates: Partial<typeof state.cis>) => {
    setState((prev) => ({ ...prev, cis: { ...prev.cis, ...updates } }));
  };

  const updateSynapse = (updates: Partial<typeof state.synapse>) => {
    setState((prev) => ({ ...prev, synapse: { ...prev.synapse, ...updates } }));
  };

  const updatePower = (updates: Partial<typeof state.power>) => {
    setState((prev) => ({ ...prev, power: { ...prev.power, ...updates } }));
  };

  const toggleSystemRun = () => {
    setState((prev) => ({
      ...prev,
      systemIntegrator: {
        ...prev.systemIntegrator,
        isRunning: !prev.systemIntegrator.isRunning,
      },
    }));
  };

  return (
    <div className="min-h-screen bg-cyber-dark text-slate-100 flex flex-col selection:bg-cyber-cyan/35 selection:text-white">
      {/* Premium Laboratory Header */}
      <header className="border-b border-slate-800/80 bg-slate-950/60 backdrop-blur px-6 py-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-cyber-cyan/15 border border-cyber-cyan/20 rounded-lg text-cyber-cyan glow-cyan">
            <Cpu className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight text-slate-100 font-sans">
                CNFET 類神經 CMOS 運算與感測實驗室
              </h1>
              <span className="text-[10px] bg-cyber-green/15 border border-cyber-green/35 text-cyber-green font-mono px-2 py-0.5 rounded-full animate-pulse uppercase">
                PLC Link Active
              </span>
            </div>
            <p className="text-xs text-slate-400">
              碳奈米管場效電晶體與鐵電類神經突觸微電子物理模擬平台 (CNFET-based Neuromorphic CIS Lab)
            </p>
          </div>
        </div>

        {/* Dynamic Status lights */}
        <div className="flex gap-4 font-mono text-[10px] text-slate-400">
          <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800/60 px-2.5 py-1 rounded">
            <span className={`w-2 h-2 rounded-full ${state.fet.channelState !== 'cut-off' ? 'bg-cyber-green' : 'bg-slate-600'}`} />
            FET: {state.fet.channelState.toUpperCase()}
          </div>
          <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800/60 px-2.5 py-1 rounded">
            <span className="w-2 h-2 rounded-full bg-cyber-cyan" />
            CNT Channel: {state.cnfet.material === 'swcnt' ? 'SWCNT' : state.cnfet.material === 'mwcnt' ? 'MWCNT' : 'Graphene'}
          </div>
          <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800/60 px-2.5 py-1 rounded">
            <span className={`w-2 h-2 rounded-full ${state.power.powerGatingState === 'sleep' ? 'bg-cyber-pink animate-ping' : 'bg-cyber-green'}`} />
            PMIC: {state.power.powerGatingState.toUpperCase()}
          </div>
        </div>
      </header>

      {/* Main Interactive Work Bench Workspace */}
      <main className="flex-1 p-6 max-w-7xl w-full mx-auto space-y-6">
        
        {/* Concept Introduction Box */}
        <div className="bg-cyber-card/40 border border-slate-800/50 p-4 rounded-xl flex items-start gap-3 text-xs leading-relaxed">
          <Sparkles className="w-5 h-5 text-cyber-cyan shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold text-slate-200">系統架構：</span>
            本模擬系統基於<strong>碳奈米管場效電晶體 (CNFET)</strong> 架構，利用 <strong>CMOS 影像感測陣列 (CIS)</strong> 進行實時環境資訊擷取。
            透過 <strong>FeFET 類神經突觸單元</strong> 處理複雜的邏輯推演，並由 <strong>高頻功率 MOSFET</strong> 確保在不穩定的電源供給（間歇性環境）下，
            依然能精確執行由 <strong>PLC 邏輯電路</strong> 觸發的高速開關動作。您可以在各模組中手動調節物理參數，或點擊上方「啟動全晶片整合模擬」查看協同運作流程。
          </div>
        </div>

        {/* Level 1: System Integrator Pipeline */}
        <SystemIntegrator systemState={state} onToggleRun={toggleSystemRun} />

        {/* Level 2: Bento Grid of Subsystems & AI Advisor */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Column 1: Gate Logic & CNFET */}
          <div className="space-y-6">
            <GateControl state={state.fet} onChange={updateFet} />
            <CarbonNanotube state={state.cnfet} onChange={updateCnfet} />
          </div>

          {/* Column 2: CMOS CIS & Neuromorphic FeFET */}
          <div className="space-y-6">
            <ImageSensor state={state.cis} onChange={updateCis} />
            <Neuromorphic state={state.synapse} onChange={updateSynapse} />
          </div>

          {/* Column 3: Power Management & AI Assistant */}
          <div className="space-y-6">
            <PowerManagement state={state.power} onChange={updatePower} />
            <AIConsultant systemState={state} />
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/60 bg-slate-950/40 py-4 px-6 text-center text-[10px] text-slate-500 font-mono">
        <div>CNFET Neuromorphic CMOS Lab Simulation System • UTC Time: 2026-07-20 20:25:05</div>
        <div className="mt-1">Designed with extreme visual precision representing solid-state devices and organic carbon architectures.</div>
      </footer>
    </div>
  );
}
